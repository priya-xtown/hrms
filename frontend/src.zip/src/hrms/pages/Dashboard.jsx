
const HrmsDashboard = () => (
 <div className=" flex flex-col">
    <div className="flex-1 p-4 text-2xl font-semibold">
      HRMS Dashboard Content
    </div>
  </div>
);

export default HrmsDashboard;
