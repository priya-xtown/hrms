import { Routes, Route } from "react-router-dom";
// import EmployeeList from "./pages/EmployeeList";
// import { TeamOutlined } from "@ant-design/icons";

import Shiftconfiguration from "./pages/ShiftConfig/ShiftConfiguration";
import RoleMaster from "./pages/Rolemaster/RoleMasters";
import HrmsDashboard from "./pages/Dashboard";
import AttendanceMaster from "./pages/AttendanceMaster/AttendanceMaster";
import Shift from "./pages/ShiftMaster/Shift";
import Shiftform from "./pages/ShiftMaster/Shiftform";
import Employee from "./pages/EmployeeMaster/Employee";
import EmployeeForm from "./pages/EmployeeMaster/Employeeform";
import Shiftconfigform from "./pages/ShiftConfig/ShiftConfigform";
import {
  UsergroupDeleteOutlined,
  HistoryOutlined,
  FileDoneOutlined,
  ContactsOutlined,
  UserSwitchOutlined,
} from "@ant-design/icons";

export const hrmsMenuItems = [
  // {
  //   icon: <TeamOutlined />,
  //   key: "employees",
  //   label: "Employees",
  //   children: [
  //     {

  //       key: "/hrms/pages/employeelist",
  //       label: "Employee List",
  //     },
  //     {
  //       key: "/hrms/pages/Rolemaster",
  //       label: "Role Master "
  //     }
  //   ],

  // },

  {
    icon: <UsergroupDeleteOutlined />,
    key: "/hrms/pages/employee",
    label: "Employee ",
  },
  {
    icon: <ContactsOutlined />,
    key: "/hrms/pages/Rolemaster",
    label: "Designation",
  },

  {
    icon: <HistoryOutlined />,
    key: "/hrms/pages/shift",
    label: "Shift",
  },
  {
    icon: <UserSwitchOutlined />,
    key: "/hrms/pages/shiftconfiguration",
    label: "Shiftconfiguration",
  },

  {
    icon: <FileDoneOutlined />,
    key: "/hrms/pages/attendance",
    label: "Attendance",
  },
];

const HRMSRoutes = () => {
  return (
    <Routes>
      <Route path="pages/employee" element={<Employee />} />
      <Route path="pages/create" element={<EmployeeForm />} />
      <Route path="pages/dashboard" element={<HrmsDashboard />} />
      <Route path="pages/attendance" element={<AttendanceMaster />} />
      <Route path="pages/shift" element={<Shift />} />
      <Route path="pages/createshift" element={<Shiftform />} />
      {/* <Route path="pages/employeelist" element={<EmployeeList />} /> */}
      <Route path="pages/rolemaster" element={<RoleMaster />} />
      <Route path="pages/shiftconfiguration" element={<Shiftconfiguration />} />
      <Route path="pages/formcreate" element={<Shiftconfigform />} />
    </Routes>
  );
};

export default HRMSRoutes;
