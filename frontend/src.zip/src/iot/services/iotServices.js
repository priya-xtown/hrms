import api from './api';

// IoT device service
export const deviceService = {
  getAllDevices: () => api.get('/devices'),
  getDeviceById: (id) => api.get(`/devices/${id}`),
  addDevice: (deviceData) => api.post('/devices', deviceData),
  updateDevice: (id, deviceData) => api.put(`/devices/${id}`, deviceData),
  deleteDevice: (id) => api.delete(`/devices/${id}`),
  getDeviceStats: (id, params) => api.get(`/devices/${id}/stats`, { params }),
};

// IoT reports service
export const reportService = {
  getReportData: (params) => api.get('/reports', { params }),
  exportReport: (params) => api.get('/reports/export', { 
    params,
    responseType: 'blob'
  }),
};

// IoT settings service
export const settingsService = {
  getSettings: () => api.get('/settings'),
  updateSettings: (settingsData) => api.put('/settings', settingsData),
};