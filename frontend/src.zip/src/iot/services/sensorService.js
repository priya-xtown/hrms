import api from "./api.js";
import { message } from "antd";

// Helper function to extract success message
function extractMessage(response, defaultMsg) {
  const msg = response.data?.message || defaultMsg;
  console.log("Extracted success message:", msg);
  return msg;
}

// Helper function to extract error message
function extractErrorMessage(error, defaultMsg) {
  let errMsg;
  if (error.response) {
    errMsg =
      error.response.data?.message ||
      error.response.data?.error ||
      (Array.isArray(error.response.data?.errors)
        ? error.response.data.errors.join(", ")
        : error.response.data?.errors) ||
      defaultMsg ||
      "Something went wrong";
  } else if (error.request) {
    errMsg = "Network error: Unable to reach the server";
  } else {
    errMsg = error.message || "Unexpected error occurred";
  }
  console.error("Extracted error message:", errMsg, "Error details:", error);
  return errMsg;
}

export const sensorService = {
  // Create Sensor
  createSensor: async (sensorData) => {
    try {
      const payload = {
        sensor_name: sensorData.sensor_name,
        sensor_description: sensorData.sensor_description,
        ip: sensorData.ip,
        serial_no: sensorData.serial_no,
        company_id: sensorData.company_id
          ? Number(sensorData.company_id)
          : undefined,
        division_id: sensorData.division_id
          ? Number(sensorData.division_id)
          : undefined,
        branch_id: sensorData.branch_id
          ? Number(sensorData.branch_id)
          : undefined,
        line_id: sensorData.line_id ? Number(sensorData.line_id) : undefined,
        machine_id: sensorData.machine_id
          ? Number(sensorData.machine_id)
          : undefined,
        department_id: sensorData.department_id
          ? Number(sensorData.department_id)
          : undefined,
        status: sensorData.status?.toLowerCase() || "active",
      };

      // Validate required fields
      const requiredFields = [
        "sensor_name",
        "sensor_description",
        "ip",
        "serial_no",
      ];
      const missingFields = requiredFields.filter((field) => !payload[field]);
      if (missingFields.length > 0) {
        throw new Error(`Missing required fields: ${missingFields.join(", ")}`);
      }

      // Validate optional numeric fields
      const numericFields = [
        "company_id",
        "division_id",
        "branch_id",
        "line_id",
        "machine_id",
        "department_id",
      ];
      numericFields.forEach((field) => {
        if (
          payload[field] !== undefined &&
          (isNaN(payload[field]) || payload[field] <= 0)
        ) {
          throw new Error(`Invalid ${field.replace("_id", " ID")} provided`);
        }
      });

      // Remove undefined fields to match Zod schema
      const cleanedPayload = Object.fromEntries(
        Object.entries(payload).filter(([_, value]) => value !== undefined)
      );

      console.log("Payload sent to backend:", cleanedPayload); // Debugging
      const res = await api.post("ssms/sensor/", cleanedPayload);
      const msg = extractMessage(res, "Sensor created successfully");
      message.success(msg);
      return { success: true, data: res.data.data, statusCode: res.status };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to create sensor");
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid sensor data provided");
          break;
        case 404:
          errMsg = "Resource not found";
          break;
        case 409:
          errMsg = "Duplicate sensor data entered";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = error.response?.data?.message?.includes("line")
            ? "Invalid or missing line ID. Please select a valid line or leave it blank if optional."
            : "Server error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },

  // Update Sensor
  updateSensor: async (id, sensorData) => {
    if (!id) {
      throw new Error("Sensor ID is required for update");
    }

    try {
      const payload = {
        sensor_name: sensorData.sensor_name,
        sensor_description: sensorData.sensor_description,
        ip: sensorData.ip,
        serial_no: sensorData.serial_no,
        company_id: sensorData.company_id
          ? Number(sensorData.company_id)
          : undefined,
        division_id: sensorData.division_id
          ? Number(sensorData.division_id)
          : undefined,
        branch_id: sensorData.branch_id
          ? Number(sensorData.branch_id)
          : undefined,
        line_id: sensorData.line_id ? Number(sensorData.line_id) : undefined,
        machine_id: sensorData.machine_id
          ? Number(sensorData.machine_id)
          : undefined,
        department_id: sensorData.department_id
          ? Number(sensorData.department_id)
          : undefined,
        status: sensorData.status?.toLowerCase() || "active",
      };

      // Validate required fields
      const requiredFields = [
        "sensor_name",
        "sensor_description",
        "ip",
        "serial_no",
      ];
      const missingFields = requiredFields.filter((field) => !payload[field]);
      if (missingFields.length > 0) {
        throw new Error(`Missing required fields: ${missingFields.join(", ")}`);
      }

      // Validate optional numeric fields
      const numericFields = [
        "company_id",
        "division_id",
        "branch_id",
        "line_id",
        "machine_id",
        "department_id",
      ];
      numericFields.forEach((field) => {
        if (
          payload[field] !== undefined &&
          (isNaN(payload[field]) || payload[field] <= 0)
        ) {
          throw new Error(`Invalid ${field.replace("_id", " ID")} provided`);
        }
      });

      // Remove undefined fields to match Zod schema
      const cleanedPayload = Object.fromEntries(
        Object.entries(payload).filter(([_, value]) => value !== undefined)
      );

      console.log("Payload sent to backend:", cleanedPayload); // Debugging
      const response = await api.put(`ssms/sensor/${id}/`, cleanedPayload);
      const msg = extractMessage(response, "Sensor updated successfully");
      message.success(msg);
      return {
        success: true,
        data: response.data,
        statusCode: response.status,
      };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to update sensor");
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid sensor data provided");
          break;
        case 404:
          errMsg = "Sensor not found";
          break;
        case 409:
          errMsg = "Duplicate sensor data entered";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = error.response?.data?.message?.includes("line")
            ? "Invalid or missing line ID. Please select a valid line or leave it blank if optional."
            : "Server error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },

  // Get Sensors
  getSensors: async (params = {}) => {
    try {
      const defaultParams = {
        page: 1,
        limit: 10,
        search: "",
        sort_by: "created_at",
        sort_order: "desc",
      };

      const queryParams = { ...defaultParams, ...params };
      const response = await api.get("ssms/sensor/", { params: queryParams });
      return response.data;
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to fetch sensors");
      message.error(errMsg);
      throw error;
    }
  },

  // Get Sensor by ID
  getSensorById: async (id) => {
    try {
      const response = await api.get(`ssms/sensor/${id}/`);
      return response.data;
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to fetch sensor");
      message.error(errMsg);
      throw error;
    }
  },

  // Delete Sensor
  deleteSensor: async (id) => {
    try {
      const response = await api.delete(`ssms/sensor/${id}/`);
      const msg = extractMessage(response, "Sensor deleted successfully");
      message.success(msg);
      return {
        success: true,
        data: response.data,
        statusCode: response.status,
      };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to delete sensor");
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid request");
          break;
        case 404:
          errMsg = "Sensor not found";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = "Server error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },
};
