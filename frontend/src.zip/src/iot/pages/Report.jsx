import { useState, useEffect } from 'react';
import { 
  Card, 
  Row, 
  Col, 
  DatePicker, 
  Button, 
  Table, 
  Select, 
  Space,
  Tabs,
  Statistic,
  Divider
} from 'antd';
import { 
  DownloadOutlined, 
  FilterOutlined, 
  LineChartOutlined,
  BarChartOutlined,
  PieChartOutlined
} from '@ant-design/icons';
import dayjs from 'dayjs';

const { RangePicker } = DatePicker;
const { Option } = Select;
const { TabPane } = Tabs;

const Report = () => {
  const [loading, setLoading] = useState(true);
  const [reportData, setReportData] = useState([]);
  const [dateRange, setDateRange] = useState([
    dayjs().subtract(7, 'day'),
    dayjs()
  ]);
  const [deviceFilter, setDeviceFilter] = useState('all');

  // Simulating data fetch
  useEffect(() => {
    setLoading(true);
    // This would be an API call in a real application
    setTimeout(() => {
      const mockData = [];
      const startDate = dateRange[0].toDate();
      const endDate = dateRange[1].toDate();
      const dayDiff = dateRange[1].diff(dateRange[0], 'day');
      
      for (let i = 0; i <= dayDiff; i++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + i);
        
        // Generate random data for each device
        mockData.push({
          id: i + 1,
          date: currentDate.toISOString(),
          deviceId: 1,
          deviceName: 'Temperature Sensor',
          avgValue: (20 + Math.random() * 10).toFixed(1),
          minValue: (15 + Math.random() * 5).toFixed(1),
          maxValue: (25 + Math.random() * 10).toFixed(1),
          alerts: Math.floor(Math.random() * 3),
          uptime: 95 + Math.random() * 5,
        });
        
        mockData.push({
          id: i + 100,
          date: currentDate.toISOString(),
          deviceId: 2,
          deviceName: 'Humidity Sensor',
          avgValue: (50 + Math.random() * 20).toFixed(1),
          minValue: (40 + Math.random() * 10).toFixed(1),
          maxValue: (60 + Math.random() * 20).toFixed(1),
          alerts: Math.floor(Math.random() * 3),
          uptime: 95 + Math.random() * 5,
        });
      }
      
      setReportData(mockData);
      setLoading(false);
    }, 1000);
  }, [dateRange, deviceFilter]);

  const handleDateChange = (dates) => {
    setDateRange(dates);
  };

  const handleDeviceChange = (value) => {
    setDeviceFilter(value);
  };

  const handleExport = () => {
    // In a real application, this would generate and download a CSV/Excel file
    alert('Exporting report data...');
  };

  const columns = [
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: date => new Date(date).toLocaleDateString(),
      sorter: (a, b) => new Date(a.date) - new Date(b.date),
    },
    {
      title: 'Device',
      dataIndex: 'deviceName',
      key: 'deviceName',
      filters: [
        { text: 'Temperature Sensor', value: 'Temperature Sensor' },
        { text: 'Humidity Sensor', value: 'Humidity Sensor' },
      ],
      onFilter: (value, record) => record.deviceName === value,
    },
    {
      title: 'Average',
      dataIndex: 'avgValue',
      key: 'avgValue',
      sorter: (a, b) => a.avgValue - b.avgValue,
    },
    {
      title: 'Minimum',
      dataIndex: 'minValue',
      key: 'minValue',
      sorter: (a, b) => a.minValue - b.minValue,
    },
    {
      title: 'Maximum',
      dataIndex: 'maxValue',
      key: 'maxValue',
      sorter: (a, b) => a.maxValue - b.maxValue,
    },
    {
      title: 'Alerts',
      dataIndex: 'alerts',
      key: 'alerts',
      sorter: (a, b) => a.alerts - b.alerts,
    },
    {
      title: 'Uptime (%)',
      dataIndex: 'uptime',
      key: 'uptime',
      render: uptime => uptime.toFixed(2) + '%',
      sorter: (a, b) => a.uptime - b.uptime,
    },
  ];

  // Calculate summary statistics
  const filteredData = deviceFilter === 'all' 
    ? reportData 
    : reportData.filter(item => item.deviceId === parseInt(deviceFilter));

  const avgTemperature = filteredData
    .filter(item => item.deviceName === 'Temperature Sensor')
    .reduce((sum, item) => sum + parseFloat(item.avgValue), 0) / 
    (filteredData.filter(item => item.deviceName === 'Temperature Sensor').length || 1);

  const avgHumidity = filteredData
    .filter(item => item.deviceName === 'Humidity Sensor')
    .reduce((sum, item) => sum + parseFloat(item.avgValue), 0) / 
    (filteredData.filter(item => item.deviceName === 'Humidity Sensor').length || 1);

  const totalAlerts = filteredData.reduce((sum, item) => sum + item.alerts, 0);

  const avgUptime = filteredData.reduce((sum, item) => sum + item.uptime, 0) / 
    (filteredData.length || 1);

  return (
    <div className="report-page">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-semibold">IoT Reports</h1>
        <Button 
          type="primary" 
          icon={<DownloadOutlined />} 
          onClick={handleExport}
        >
          Export Report
        </Button>
      </div>

      <Card bordered={false} className="mb-4">
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <div className="mb-2">Date Range</div>
            <RangePicker 
              value={dateRange} 
              onChange={handleDateChange} 
              allowClear={false}
            />
          </div>
          <div>
            <div className="mb-2">Device</div>
            <Select 
              defaultValue="all" 
              style={{ width: 200 }} 
              onChange={handleDeviceChange}
            >
              <Option value="all">All Devices</Option>
              <Option value="1">Temperature Sensor</Option>
              <Option value="2">Humidity Sensor</Option>
            </Select>
          </div>
          <Button 
            type="primary" 
            icon={<FilterOutlined />}
            onClick={() => setLoading(true)}
            loading={loading}
          >
            Apply Filters
          </Button>
        </div>
      </Card>

      <Row gutter={[16, 16]} className="mb-4">
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false}>
            <Statistic 
              title="Avg. Temperature" 
              value={avgTemperature.toFixed(1)} 
              suffix="°C"
              precision={1}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false}>
            <Statistic 
              title="Avg. Humidity" 
              value={avgHumidity.toFixed(1)} 
              suffix="%"
              precision={1}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false}>
            <Statistic 
              title="Total Alerts" 
              value={totalAlerts} 
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false}>
            <Statistic 
              title="Avg. Uptime" 
              value={avgUptime.toFixed(2)} 
              suffix="%"
              precision={2}
            />
          </Card>
        </Col>
      </Row>

      <Card bordered={false}>
        <Tabs defaultActiveKey="table">
          <TabPane 
            tab={<span><LineChartOutlined /> Line Chart</span>}
            key="line"
          >
            <div className="h-64 flex items-center justify-center bg-gray-100 rounded">
              <p className="text-gray-500">Line chart visualization would appear here</p>
            </div>
          </TabPane>
          <TabPane 
            tab={<span><BarChartOutlined /> Bar Chart</span>}
            key="bar"
          >
            <div className="h-64 flex items-center justify-center bg-gray-100 rounded">
              <p className="text-gray-500">Bar chart visualization would appear here</p>
            </div>
          </TabPane>
          <TabPane 
            tab={<span><PieChartOutlined /> Pie Chart</span>}
            key="pie"
          >
            <div className="h-64 flex items-center justify-center bg-gray-100 rounded">
              <p className="text-gray-500">Pie chart visualization would appear here</p>
            </div>
          </TabPane>
          <TabPane 
            tab={<span>Table View</span>}
            key="table"
          >
            <Table 
              columns={columns} 
              dataSource={filteredData} 
              rowKey="id" 
              loading={loading}
              pagination={{ pageSize: 10 }}
            />
          </TabPane>
        </Tabs>
      </Card>
    </div>
  );
};

export default Report;