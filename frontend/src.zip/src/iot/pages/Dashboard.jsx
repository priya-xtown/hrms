const IotDashboard = () => (
  <div className="text-2xl font-semibold">IOT Dashboard Content</div>
);

export default IotDashboard;
