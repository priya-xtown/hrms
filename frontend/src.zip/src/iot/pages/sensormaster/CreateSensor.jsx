import { useState, useEffect } from "react";
import { Form, Input, Select, Button, Space, message } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import { companyService } from "../../../company/services/CompanyServices"; // Adjust path as needed
import { divisionService } from "../../../company/services/divisionService";
import { departmentService } from "../../../company/services/departmentService";
import { branchServices } from "../../../company/services/CompanyServices";
import { controllerService } from "../../../ssms/services/Controller";
import { machineService } from "../../../ssms/services/Machineservices";
import { sensorService } from "../../services/sensorService";

const { Option } = Select;

const CreateSensor = () => {
  const { state } = useLocation();
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const [companies, setCompanies] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [branches, setBranches] = useState([]);
  const [lines, setLines] = useState([]);
  const [machines, setMachines] = useState([]);
  const [loading, setLoading] = useState(false);

  const pageTitle = state?.isEdit ? "Edit Sensor" : "Add New Sensor";

  // Populate form fields if editing
  useEffect(() => {
    if (state?.isEdit && state?.initialValues) {
      const initialValues = {
        sensor_name: state.initialValues.sensor_name || "",
        sensor_description: state.initialValues.sensor_description || "",
        ip: state.initialValues.ip || "",
        serial_no: state.initialValues.serial_no || "",
        line_id: state.initialValues.line_id || undefined,
        machine_id: state.initialValues.machine_id || undefined,
        department_id: state.initialValues.department_id || undefined,
        company_id: state.initialValues.company_id || undefined,
        division_id: state.initialValues.division_id || undefined,
        branch_id: state.initialValues.branch_id || undefined,
        status: state.initialValues.status || "active",
      };

      // Validate numeric IDs
      Object.keys(initialValues).forEach((key) => {
        if (
          key.endsWith("_id") &&
          (isNaN(Number(initialValues[key])) || Number(initialValues[key]) <= 0)
        ) {
          initialValues[key] = undefined;
        }
      });

      console.log("Setting initial values:", initialValues); // Debug log
      form.setFieldsValue(initialValues);
    }
  }, [form, state]);

  // Fetch dropdown data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [
          companyRes,
          divisionRes,
          departmentRes,
          branchRes,
          lineRes,
          machineRes,
        ] = await Promise.all([
          companyService.getCompany(),
          divisionService.getAllDivisions(),
          departmentService.getAllDepartments(),
          branchServices.getBranch(),
          controllerService.getAllController(),
          machineService.getMachines({ page: 1, limit: 1000 }),
        ]);

        setCompanies(
          Array.isArray(companyRes?.data?.data) ? companyRes.data.data : []
        );
        setDivisions(
          Array.isArray(divisionRes?.data?.divisions)
            ? divisionRes.data.divisions
            : []
        );
        setDepartments(
          Array.isArray(departmentRes?.data?.departments)
            ? departmentRes.data.departments
            : []
        );
        setBranches(
          Array.isArray(branchRes?.data?.data?.branches)
            ? branchRes.data.data.branches
            : []
        );
        setLines(Array.isArray(lineRes?.data?.data) ? lineRes.data.data : []);
        setMachines(
          Array.isArray(machineRes?.data?.data) ? machineRes.data.data : []
        );
      } catch (error) {
        console.error("Error fetching dropdown data:", error);
        message.error("Failed to fetch dropdown data");
      }
    };

    fetchData();
  }, []);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const payload = {
        sensor_name: values.sensor_name,
        sensor_description: values.sensor_description,
        serial_no: values.serial_no,
        ip: values.ip,
        line_id: Number(values.line_id),
        machine_id: Number(values.machine_id),
        status: values.status?.toLowerCase() || "active",
      };

      console.log("Form payload:", payload);

      let response;
      if (state?.isEdit) {
        response = await sensorService.updateSensor(
          state.initialValues.id,
          payload
        );
        if (response.success) {
          message.success("Sensor updated successfully");
          navigate("/iot/pages/sensormaster");
        } else {
          throw new Error(response.error || "Failed to update sensor");
        }
      } else {
        response = await sensorService.createSensor(payload);
        if (response.success) {
          message.success("Sensor created successfully");
          navigate("/iot/pages/sensormaster");
        } else {
          throw new Error(response.error || "Failed to create sensor");
        }
      }
    } catch (error) {
      console.error("Form submission error:", error);
      message.error(
        error.message ||
          `Failed to ${state?.isEdit ? "update" : "create"} sensor`
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-2 bg-white">
      <div className="max-w-8xl mx-auto">
        <h1 className="text-xl font-semibold mb-3">{pageTitle}</h1>

        <Form
          form={form}
          onFinish={handleSubmit}
          layout="vertical"
          className="space-y-4"
        >
          <div className="grid xs:grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <Form.Item
              name="sensor_name"
              label="Sensor Name"
              rules={[{ required: true, message: "Please enter sensor name" }]}
            >
              <Input placeholder="Enter sensor name" className="rounded-lg" />
            </Form.Item>

            <Form.Item
              name="ip"
              label="IP Address"
              rules={[{ required: true, message: "Please enter IP address" }]}
            >
              <Input placeholder="Enter IP address" className="rounded-lg" />
            </Form.Item>

            <Form.Item
              name="serial_no"
              label="Serial No"
              rules={[
                { required: true, message: "Please enter serial number" },
              ]}
            >
              <Input placeholder="Enter serial number" className="rounded-lg" />
            </Form.Item>

            <Form.Item
              name="machine_id"
              label="Machine"
              rules={[{ required: true, message: "Please select machine" }]}
            >
              <Select
                placeholder="Select machine"
                showSearch
                allowClear
                optionFilterProp="children"
              >
                {machines.map((machine) => (
                  <Option key={machine.id} value={machine.id}>
                    {machine.machine_name}
                  </Option>
                ))}
              </Select>
            </Form.Item>

            <Form.Item
              name="line_id"
              label="Line"
              rules={[{ required: true, message: "Please select line" }]}
            >
              <Select
                placeholder="Select line"
                showSearch
                allowClear
                optionFilterProp="children"
              >
                {lines.map((line) => (
                  //  💡 Likewise, `line.id` should be a number
                  <Option key={line.id} value={line.id}>
                    {line.line_name}
                  </Option>
                ))}
              </Select>
            </Form.Item>

            <Form.Item
              name="sensor_description"
              label="Description"
              rules={[{ required: true, message: "Please enter description" }]}
            >
              <Input.TextArea
                placeholder="Enter description"
                className="rounded-lg"
                rows={4}
              />
            </Form.Item>

            {state?.isEdit && (
              <Form.Item
                name="status"
                label="Status"
                rules={[{ required: true, message: "Please select status" }]}
                initialValue="active"
              >
                <Select
                  placeholder="Select status"
                  className="rounded-lg"
                  options={[
                    { value: "active", label: "Active" },
                    { value: "inactive", label: "Inactive" },
                  ]}
                />
              </Form.Item>
            )}
          </div>

          <Form.Item className="flex justify-end mt-6">
            <Space>
              <Button
                danger
                onClick={() => navigate("/iot/pages/sensormaster")}
                className="rounded-lg"
              >
                Cancel
              </Button>
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                className="rounded-lg"
              >
                {state?.isEdit ? "Update Sensor" : "Create Sensor"}
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default CreateSensor;
