import { useState, useEffect } from "react";
import {
  Table,
  Button,
  Input,
  Popover,
  Dropdown,
  Menu,
  Tag,
  Select,
  message,
  Space,
  Card,
  Switch,
} from "antd";
import {
  PlusOutlined,
  FilterOutlined,
  EditOutlined,
  DeleteOutlined,
  EllipsisOutlined,
  SettingOutlined,
  AppstoreOutlined,
  TableOutlined,
} from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import { companyService } from "../../../company/services/CompanyServices";
import { divisionService } from "../../../company/services/divisionService";
import { departmentService } from "../../../company/services/departmentService";
import { branchServices } from "../../../company/services/CompanyServices";
import { controllerService } from "../../../ssms/services/Controller";
import { machineService } from "../../../ssms/services/Machineservices";
import { sensorService } from "../../services/sensorService";
import { useTheme } from "../../../context/ThemeContext";

const { Option } = Select;

const FiltersPopover = ({
  onApply,
  companies,
  divisions,
  branches,
  departments,
  lines,
  machines,
}) => {
  const [filters, setFilters] = useState({
    companyId: undefined,
    divisionId: undefined,
    branchId: undefined,
    departmentId: undefined,
    lineId: undefined,
    machineId: undefined,
    status: undefined,
  });

  const onChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  const fields = [
    // {
    //   key: "companyId",
    //   label: "Company",
    //   options: companies.map((c) => ({ label: c.name, value: c.id })),
    // },
    {
      key: "divisionId",
      label: "Division",
      options: divisions.map((d) => ({ label: d.name, value: d.id })),
    },
    {
      key: "branchId",
      label: "Branch",
      options: branches.map((b) => ({ label: b.name, value: b.id })),
    },
    {
      key: "departmentId",
      label: "Department",
      options: departments.map((d) => ({ label: d.name, value: d.id })),
    },
    {
      key: "lineId",
      label: "Line",
      options: lines.map((l) => ({ label: l.line_name, value: l.id })),
    },
    {
      key: "machineId",
      label: "Machine",
      options: machines.map((m) => ({ label: m.machine_name, value: m.id })),
    },
    {
      key: "status",
      label: "Status",
      options: [
        { label: "Active", value: "active" },
        { label: "Inactive", value: "inactive" },
      ],
    },
  ];

  const handleApplyClick = () => {
    const payload = {
      company_id: filters.companyId,
      division_id: filters.divisionId,
      branch_id: filters.branchId,
      department_id: filters.departmentId,
      line_id: filters.lineId,
      machine_id: filters.machineId,
      status: filters.status,
    };
    onApply(payload);
  };
  const capitalizeFirstLetter = (str) => {
    if (!str) return str; // Handle empty or undefined strings
    return str.charAt(0).toUpperCase() + str.slice(1);
  };
  return (
    <div style={{ padding: 10, width: 220 }}>
      {fields.map(({ key, label, options }) => (
        <div key={key} style={{ marginBottom: 15 }}>
          <Popover
            content={
              <div>
                <div
                  style={{ marginBottom: 6, fontWeight: 600, color: "#555" }}
                >
                  {label}
                </div>
                <Select
                  showSearch
                  allowClear
                  placeholder={`Select ${label.toLowerCase()}`}
                  style={{ width: 180 }}
                  value={filters[key]}
                  onChange={(val) => onChange(key, val)}
                >
                  {options.map((opt) => (
                    <Option key={opt.value} value={opt.value}>
                      {opt.label || opt.value}
                    </Option>
                  ))}
                </Select>
              </div>
            }
            trigger="hover"
            placement="right"
            mouseEnterDelay={0.1}
            mouseLeaveDelay={0.1}
          >
            <div
              style={{
                cursor: "pointer",
                fontWeight: 500,
                color: filters[key] ? "#1890ff" : "inherit",
              }}
            >
              {label}
              {filters[key] && <span style={{ marginLeft: 4 }}>(1)</span>}
            </div>
          </Popover>
        </div>
      ))}

      <div style={{ textAlign: "center", marginTop: 10 }}>
        <Button
          danger
          size="small"
          onClick={() => {
            setFilters({
              companyId: undefined,
              divisionId: undefined,
              branchId: undefined,
              departmentId: undefined,
              lineId: undefined,
              machineId: undefined,
              status: undefined,
            });
            onApply({});
          }}
          disabled={!Object.values(filters).some((v) => v !== undefined)}
        >
          Reset
        </Button>
        <Button
          type="primary"
          size="small"
          style={{ marginLeft: 8 }}
          onClick={handleApplyClick}
          disabled={!Object.values(filters).some((v) => v !== undefined)}
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const SensorMaster = () => {
  const { primaryColor, contentBgColor, showCustomButton } = useTheme();
  const [sensors, setSensors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [companies, setCompanies] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [branches, setBranches] = useState([]);
  const [lines, setLines] = useState([]);
  const [machines, setMachines] = useState([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);

  const navigate = useNavigate();

  const [viewMode, setViewMode] = useState(
    localStorage.getItem("sensorViewMode") || "table"
  );
  useEffect(() => {
    localStorage.setItem("sensorViewMode", viewMode);
  }, [viewMode]);

  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });

  useEffect(() => {
    const fetchMasters = async () => {
      try {
        const [
          companyRes,
          divisionRes,
          departmentRes,
          branchRes,
          lineRes,
          machineRes,
        ] = await Promise.all([
          companyService.getCompany(),
          divisionService.getAllDivisions(),
          departmentService.getAllDepartments(),
          branchServices.getBranch(),
          controllerService.getAllController(),
          machineService.getMachines({ page: 1, limit: 1000 }),
        ]);

        setCompanies(
          Array.isArray(companyRes?.data?.data) ? companyRes.data.data : []
        );
        setDivisions(
          Array.isArray(divisionRes?.data?.divisions)
            ? divisionRes.data.divisions
            : []
        );
        setDepartments(
          Array.isArray(departmentRes?.data?.departments)
            ? departmentRes.data.departments
            : []
        );
        setBranches(
          Array.isArray(branchRes?.data?.data?.branches)
            ? branchRes.data.data.branches
            : []
        );
        setLines(Array.isArray(lineRes?.data?.data) ? lineRes.data.data : []);
        setMachines(
          Array.isArray(machineRes?.data?.data) ? machineRes.data.data : []
        );
      } catch (error) {
        console.error("Error fetching master data:", error);
        message.error("Failed to load filter lists");
      }
    };
    fetchMasters();
  }, []);

  const handleEdit = (record) => {
    navigate("/iot/pages/sensormaster/create", {
      state: {
        isEdit: true,
        initialValues: {
          id: record.id,
          sensor_name: record.sensor_name,
          sensor_description: record.sensor_description,
          serial_no: record.serial_no,
          ip: record.ip,
          company_id: record.company?.id,
          division_id: record.division?.id,
          branch_id: record.branch?.id,
          line_id: record.line?.id,
          machine_id: record.machine?.id,
          department_id: record.department?.id,
          status: record.status || "active",
        },
      },
    });
  };

  const fetchSensors = async (params = {}) => {
    setLoading(true);
    try {
      const requestParams = {
        page: params.page ?? pagination.current,
        limit: params.pageSize ?? pagination.pageSize,
        search: searchText,
        sort_by: "created_at",
        sort_order: "desc",
        ...params,
      };

      const response = await sensorService.getSensors(requestParams);
      const rows = response.data || [];
      const meta = response.meta || {};

      const formatted = rows
        .filter((item) => item.id)
        .map((item) => ({
          key: item.id,
          id: item.id,
          sensor_name: item.sensor_name,
          sensor_description: item.sensor_description,
          serial_no: item.serial_no,
          ip: item.ip,
          status: item.status,
          company: item.company || {},
          division: item.division || {},
          branch: item.branch || {},
          department: item.department || {},
          line: item.line || {},
          machine: item.machine || {},
        }));

      setSensors(formatted);
      setPagination({
        current: meta.page || pagination.current,
        pageSize: meta.limit || pagination.pageSize,
        total: meta.total || pagination.total,
      });
    } catch (error) {
      console.error("Error fetching sensors:", error);
      setSensors([]);
      setPagination((prev) => ({
        current: 1,
        pageSize: prev.pageSize,
        total: 0,
      }));
      message.error(error.message || "Failed to fetch sensors");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSensors();
  }, [searchText, pagination.current, pagination.pageSize]);

  const handleFilterApply = (params) => {
    const cleanParams = Object.entries(params).reduce((acc, [key, value]) => {
      if (value !== undefined && value !== null) {
        acc[key] = value;
      }
      return acc;
    }, {});

    setPagination((prev) => ({ ...prev, current: 1 }));
    fetchSensors({ ...cleanParams, page: 1 });
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchText(value);
    setPagination((prev) => ({ ...prev, current: 1 }));
    fetchSensors({ search: value, page: 1 });
  };

  const handleMenuClick = (record, e) => {
    if (!record.id) {
      message.error("Cannot perform action: Invalid sensor ID");
      return;
    }
    if (e.key === "edit") {
      handleEdit(record);
    } else if (e.key === "delete") {
      sensorService
        .deleteSensor(record.id)
        .then(() => {
          message.success("Sensor deleted successfully");
          fetchSensors();
        })
        .catch((err) => {
          console.error("Delete error:", err);
          message.error("Failed to delete sensor");
        });
    }
  };

  const capitalizeWords = (text) => {
    if (!text || typeof text !== "string") return "-";
    return text
      .toLowerCase()
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const [visibleColumns, setVisibleColumns] = useState(() => {
    const saved = localStorage.getItem("sensorVisibleColumns");
    return saved
      ? JSON.parse(saved)
      : [
          "sensor_name",
          "company_name",
          "branch_name",
          "department_name",
          "division_name",
          "line_name",
          "ip",
          "sensor_description",
          "status",
          "actions",
        ];
  });
  useEffect(() => {
    localStorage.setItem(
      "sensorVisibleColumns",
      JSON.stringify(visibleColumns)
    ),
      [visibleColumns];
  });

  const allColumns = [
    {
      title: "S.No",
      key: "idx",
      width: 60,
      fixed: "left",
      render: (_, __, index) =>
        (pagination.current - 1) * pagination.pageSize + index + 1,
    },
    {
      title: "Sensor Name",
      dataIndex: "sensor_name",
      key: "sensor_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "IP Address",
      dataIndex: "ip",
      key: "ip",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Company",
      dataIndex: ["company", "name"],
      key: "company_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Division",
      dataIndex: ["division", "name"],
      key: "division_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Branch",
      dataIndex: ["branch", "name"],
      key: "branch_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Department",
      dataIndex: ["department", "name"],
      key: "department_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Line",
      dataIndex: ["line", "line_name"],
      key: "line_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Machine",
      dataIndex: ["machine", "machine_name"],
      key: "machine_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Description",
      dataIndex: "sensor_description",
      key: "sensor_description",
      ellipsis: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => (
        <Tag color={status === "active" ? "green" : "red"}>
          {status ? status.charAt(0).toUpperCase() + status.slice(1) : "-"}
        </Tag>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Dropdown
          overlay={
            <Menu onClick={(e) => handleMenuClick(record, e)}>
              <Menu.Item icon={<EditOutlined />} key="edit">
                Edit
              </Menu.Item>
              <Menu.Item icon={<DeleteOutlined />} key="delete">
                Delete
              </Menu.Item>
            </Menu>
          }
          trigger={["click"]}
        >
          <EllipsisOutlined className="cursor-pointer text-lg rotate-90" />
        </Dropdown>
      ),
    },
  ];

  const columns = allColumns.filter((c) => visibleColumns.includes(c.key));

  return (
    <div className="max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-2">
        <h1 className="text-xl font-semibold">Sensor</h1>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
          <div className="w-full sm:w-[250px] min-w-[200px]">
            <Input.Search
              placeholder="Search sensors"
              value={searchText}
              onChange={handleSearchChange}
              className="w-full sm:w-[250px]"
              allowClear
            />
          </div>
          <Popover
            content={
              <FiltersPopover
                onApply={handleFilterApply}
                companies={companies}
                divisions={divisions}
                branches={branches}
                departments={departments}
                lines={lines}
                machines={machines}
              />
            }
            trigger="click"
            placement="bottomRight"
          >
            <Button icon={<FilterOutlined />}>Filter</Button>
          </Popover>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => navigate("/iot/pages/sensormaster/create")}
          >
            Add Sensor
          </Button>
          {showCustomButton && (
            <Dropdown
              menu={{
                items: allColumns.map((col) => ({
                  key: col.key,
                  label: (
                    <Space>
                      <Switch
                        checked={visibleColumns.includes(col.key)}
                        onChange={(chk) => {
                          setVisibleColumns((vs) =>
                            chk
                              ? [...vs, col.key]
                              : vs.filter((k) => k !== col.key)
                          );
                        }}
                      />
                      {col.title}
                    </Space>
                  ),
                })),
              }}
            >
              <Button icon={<SettingOutlined />} />
            </Dropdown>
          )}
          <Button
            icon={
              viewMode === "table" ? <AppstoreOutlined /> : <TableOutlined />
            }
            onClick={() =>
              setViewMode((m) => (m === "table" ? "card" : "table"))
            }
          >
            {/* {viewMode === "table" ? "Card View" : "Table View"} */}
          </Button>
        </div>
      </div>

      {viewMode === "table" ? (
        <div className="overflow-x-auto">
          <Table
            rowSelection={{
              selectedRowKeys,
              onChange: setSelectedRowKeys,
            }}
            columns={columns}
            dataSource={sensors}
            loading={loading}
            rowKey="id"
            scroll={{ x: "max-content" }}
            pagination={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              showSizeChanger: true,
              showTotal: (t, r) => `${r[0]}–${r[1]} of ${t} items`,
              onChange: (page, pageSize) => {
                setPagination((p) => ({ ...p, current: page, pageSize }));
                fetchSensors({ page, pageSize });
              },
            }}
            size="small"
            components={{
              header: {
                cell: (props) => (
                  <th
                    {...props}
                    style={{
                      position: "sticky",
                      top: 0,
                      zIndex: 2,
                      padding: "8px 8px",
                      whiteSpace: "nowrap",
                    }}
                  />
                ),
              },
            }}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sensors.length ? (
            sensors.map((rec, i) => (
              <Card
                key={rec.id}
                title={`${
                  (pagination.current - 1) * pagination.pageSize + i + 1
                }. ${capitalize(rec.sensor_name)}`}
                className="shadow-sm hover:shadow-md"
              >
                <p>
                  <strong>IP:</strong> {rec.ip}
                </p>
                <p>
                  <strong>Company:</strong> {capitalize(rec.company?.name)}
                </p>
                <p>
                  <strong>Division:</strong> {capitalize(rec.division?.name)}
                </p>
                <p>
                  <strong>Branch:</strong> {capitalize(rec.branch?.name)}
                </p>
                <p>
                  <strong>Dept:</strong> {capitalize(rec.department?.name)}
                </p>
                <p>
                  <strong>Line:</strong> {capitalize(rec.line?.line_name)}
                </p>
                <p>
                  <strong>Machine:</strong>{" "}
                  {capitalize(rec.machine?.machine_name)}
                </p>
                <p>
                  <strong>Description:</strong>{" "}
                  {capitalize(rec.sensor_description)}
                </p>
                <p>
                  <strong>Status:</strong>{" "}
                  <Tag color={rec.status === "active" ? "green" : "red"}>
                    {capitalize(rec.status)}
                  </Tag>
                </p>
                <Dropdown
                  overlay={
                    <Menu onClick={(e) => handleMenuClick(rec, e)}>
                      <Menu.Item icon={<EditOutlined />} key="edit">
                        Edit
                      </Menu.Item>
                      <Menu.Item icon={<DeleteOutlined />} key="delete">
                        Delete
                      </Menu.Item>
                    </Menu>
                  }
                  trigger={["click"]}
                >
                  <EllipsisOutlined rotate={90} />
                </Dropdown>
              </Card>
            ))
          ) : (
            <div className="py-10 text-center">No sensors found</div>
          )}
        </div>
      )}
    </div>
  );
};

export default SensorMaster;
