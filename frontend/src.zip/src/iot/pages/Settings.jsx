import { useState } from 'react';
import { 
  Card, 
  Form, 
  Input, 
  Button, 
  Switch, 
  Divider, 
  Select, 
  InputNumber,
  Tabs,
  notification,
  Space
} from 'antd';
import { 
  SaveOutlined, 
  BellOutlined, 
  CloudOutlined,
  ApiOutlined,
  SecurityScanOutlined
} from '@ant-design/icons';

const { Option } = Select;
const { TabPane } = Tabs;

const Settings = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const handleSubmit = (values) => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      console.log('Settings saved:', values);
      notification.success({
        message: 'Settings Saved',
        description: 'Your IoT settings have been updated successfully.',
      });
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="settings-page">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-semibold">IoT Settings</h1>
      </div>

      <Card bordered={false}>
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          initialValues={{
            apiEndpoint: 'https://api.iot.example.com/v1',
            apiKey: '••••••••••••••••',
            dataRefreshRate: 30,
            dataRetentionDays: 90,
            alertsEnabled: true,
            emailNotifications: true,
            smsNotifications: false,
            pushNotifications: true,
            autoUpdateDevices: true,
            securityLevel: 'high'
          }}
        >
          <Tabs defaultActiveKey="general">
            <TabPane 
              tab={<span><ApiOutlined /> General</span>}
              key="general"
            >
              <Form.Item
                name="apiEndpoint"
                label="API Endpoint"
                rules={[{ required: true, message: 'Please enter API endpoint' }]}
              >
                <Input placeholder="https://api.example.com/v1" />
              </Form.Item>
              
              <Form.Item
                name="apiKey"
                label="API Key"
                rules={[{ required: true, message: 'Please enter API key' }]}
              >
                <Input.Password />
              </Form.Item>
              
              <Form.Item
                name="dataRefreshRate"
                label="Data Refresh Rate (seconds)"
                rules={[{ required: true, message: 'Please enter refresh rate' }]}
              >
                <InputNumber min={5} max={3600} style={{ width: '100%' }} />
              </Form.Item>
              
              <Form.Item
                name="dataRetentionDays"
                label="Data Retention Period (days)"
                rules={[{ required: true, message: 'Please enter retention period' }]}
              >
                <InputNumber min={1} max={365} style={{ width: '100%' }} />
              </Form.Item>
            </TabPane>
            
            <TabPane 
              tab={<span><BellOutlined /> Notifications</span>}
              key="notifications"
            >
              <Form.Item
                name="alertsEnabled"
                label="Enable Alerts"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
              
              <Divider />
              
              <Form.Item
                name="emailNotifications"
                label="Email Notifications"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
              
              <Form.Item
                name="smsNotifications"
                label="SMS Notifications"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
              
              <Form.Item
                name="pushNotifications"
                label="Push Notifications"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
            </TabPane>
            
            <TabPane 
              tab={<span><CloudOutlined /> Updates</span>}
              key="updates"
            >
              <Form.Item
                name="autoUpdateDevices"
                label="Automatic Device Updates"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
              
              <Form.Item
                name="updateSchedule"
                label="Update Schedule"
              >
                <Select>
                  <Option value="immediate">Immediate</Option>
                  <Option value="daily">Daily</Option>
                  <Option value="weekly">Weekly</Option>
                  <Option value="monthly">Monthly</Option>
                </Select>
              </Form.Item>
            </TabPane>
            
            <TabPane 
              tab={<span><SecurityScanOutlined /> Security</span>}
              key="security"
            >
              <Form.Item
                name="securityLevel"
                label="Security Level"
              >
                <Select>
                  <Option value="low">Low</Option>
                  <Option value="medium">Medium</Option>
                  <Option value="high">High</Option>
                </Select>
              </Form.Item>
              
              <Form.Item
                name="encryptionKey"
                label="Encryption Key"
              >
                <Input.Password />
              </Form.Item>
            </TabPane>
          </Tabs>
          
          <Divider />
          
          <Form.Item className="mb-0">
            <Button 
              type="primary" 
              htmlType="submit" 
              icon={<SaveOutlined />} 
              loading={loading}
            >
              Save Settings
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default Settings;