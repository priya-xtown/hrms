import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Form,
  Input,
  Select,
  Switch,
  message,
  Popover,
  Dropdown,
  Menu,
} from "antd";
import {
  PlusOutlined,
  EllipsisOutlined,
  FilterOutlined,
  EyeOutlined,
  DeleteOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { useTheme } from "../../../context/ThemeContext";
import { useNavigate } from "react-router-dom";

const { Option } = Select;

// Helper function to get unique values from data
const getUniqueValues = (data, key) =>
  [...new Set(data.map((item) => item[key]))].filter(Boolean);

// FiltersPopover Component
const FiltersPopover = ({ onApply, dataSource, currentFilters }) => {
  const [filters, setFilters] = useState({
    cctvName: currentFilters?.cctvName,
    ipAddress: currentFilters?.ipAddress,
    division: currentFilters?.division,
    department: currentFilters?.department,
    machine: currentFilters?.machine,
    status: currentFilters?.status,
  });

  const onChange = (field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const renderPopoverContent = (field) => {
    let options = [];

    switch (field) {
      case "cctvName":
        options = getUniqueValues(dataSource, "cctv_name");
        break;
      case "ipAddress":
        options = getUniqueValues(dataSource, "ip");
        break;
      case "division":
        options = getUniqueValues(dataSource, "division_name");
        break;
      case "department":
        options = getUniqueValues(dataSource, "department_name");
        break;
      case "machine":
        options = getUniqueValues(dataSource, "machine_name");
        break;
      case "status":
        options = ["active", "inactive"];
        break;
      default:
        break;
    }

    return (
      <div>
        <div style={{ marginBottom: 3, fontWeight: "bold", color: "#555" }}>
          {field.split(/(?=[A-Z])/).join(" ")}
        </div>
        <Select
          value={filters[field]}
          onChange={(val) => onChange(field, val)}
          placeholder={`Select ${field
            .split(/(?=[A-Z])/)
            .join(" ")
            .toLowerCase()}`}
          style={{ width: 180 }}
          allowClear
        >
          {options.map((opt) => (
            <Option key={opt} value={opt}>
              {opt}
            </Option>
          ))}
        </Select>
      </div>
    );
  };

  return (
    <div style={{ padding: 10, width: 200, height: "auto" }}>
      {[
        "Camera Name",
        "IpAddress",
        "Division",
        "Department",
        "Machine",
        "Status",
      ].map((field) => (
        <div key={field} style={{ marginBottom: 15 }}>
          <Popover
            content={renderPopoverContent(field)}
            trigger="hover"
            placement="right"
            mouseEnterDelay={0.1}
            mouseLeaveDelay={0.1}
          >
            <div
              style={{
                cursor: "pointer",
                fontWeight: "semibold",
                width: 100,
                color: filters[field] ? "#1890ff" : "inherit",
              }}
            >
              {field.split(/(?=[A-Z])/).join(" ")}
              {filters[field] && (
                <span className="ml-2 text-xs text-gray-500">(1)</span>
              )}
            </div>
          </Popover>
        </div>
      ))}
      <div style={{ textAlign: "center", marginTop: 20 }} className="space-x-2">
        <Button
          danger
          size="small"
          onClick={() => {
            setFilters({});
            onApply({});
          }}
          disabled={
            Object.keys(filters).filter((k) => filters[k] !== undefined)
              .length === 0
          }
        >
          Reset
        </Button>
        <Button
          type="primary"
          size="small"
          onClick={() => onApply(filters)}
          disabled={
            Object.keys(filters).filter((k) => filters[k] !== undefined)
              .length === 0
          }
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const CCTVMasterPage = () => {
  const navigate = useNavigate(); // Add this at the top with other hooks
  const { primaryColor, contentBgColor } = useTheme();

  const [form] = Form.useForm();
  const [cctvs, setCCTVs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [searchText, setSearchText] = useState("");

  const columns = [
    {
      title: "S.No",
      key: "serialNumber",
      width: 70,
      render: (_, __, index) => index + 1,
      fixed: "left",
    },
    {
      title: "Camera Name",
      dataIndex: "cctv_name",
      key: "cctv_name",
      sorter: true,
    },
    {
      title: "Description",
      dataIndex: "cctv_description",
      key: "cctv_description",
    },
    {
      title: "IP Address",
      dataIndex: "ip",
      key: "ip",
      sorter: true,
    },
    {
      title: "Division",
      dataIndex: "division_name",
      key: "division_name",
    },
    {
      title: "Department",
      dataIndex: "department_name",
      key: "department_name",
    },
    {
      title: "Machine",
      dataIndex: "machine_name",
      key: "machine_name",
    },
    {
      title: "Status",
      dataIndex: "is_active",
      key: "is_active",
      render: (active) => <Switch checked={active} disabled />,
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Dropdown
          overlay={
            <Menu onClick={(e) => handleMenuClick(record, e)}>
              {/* <Menu.Item icon={<EyeOutlined />} key="view">View</Menu.Item> */}
              <Menu.Item icon={<EditOutlined />} key="edit">
                Edit
              </Menu.Item>
              <Menu.Item icon={<DeleteOutlined />} key="delete">
                Delete
              </Menu.Item>
            </Menu>
          }
          trigger={["click"]}
        >
          <EllipsisOutlined className="cursor-pointer text-lg rotate-90" />
        </Dropdown>
      ),
    },
  ];

  const handleMenuClick = (record, e) => {
    switch (e.key) {
      case "view":
        break;
      case "edit":
        handleEdit(record);
        break;
      case "delete":
        handleDelete(record);
        break;
      default:
        break;
    }
  };

  const handleEdit = (record) => {
    setEditingRecord(record);
    form.setFieldsValue(record);
    setModalVisible(true);
  };

  const handleDelete = async (record) => {
    try {
      // Add your delete API call here
      message.success("CCTV deleted successfully");
      fetchCCTVs();
    } catch (error) {
      message.error("Failed to delete CCTV");
    }
  };

  const handleSubmit = async (values) => {
    try {
      setLoading(true);
      // Add your API calls here
      message.success(
        `CCTV ${editingRecord ? "updated" : "created"} successfully`
      );
      setModalVisible(false);
      form.resetFields();
      fetchCCTVs();
    } catch (error) {
      message.error(`Failed to ${editingRecord ? "update" : "create"} CCTV`);
    } finally {
      setLoading(false);
    }
  };

  const fetchCCTVs = async () => {
    try {
      setLoading(true);
      // Add your fetch API call here
    } catch (error) {
      message.error("Failed to fetch CCTVs");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCCTVs();
  }, []);

  const rowSelection = {
    selectedRowKeys,
    onChange: (keys) => setSelectedRowKeys(keys),
    selections: [
      Table.SELECTION_ALL,
      Table.SELECTION_INVERT,
      Table.SELECTION_NONE,
      {
        key: "odd",
        text: "Select Odd Row",
        onSelect: (changableRowKeys) =>
          setSelectedRowKeys(changableRowKeys.filter((_, i) => i % 2 === 0)),
      },
      {
        key: "even",
        text: "Select Even Row",
        onSelect: (changableRowKeys) =>
          setSelectedRowKeys(changableRowKeys.filter((_, i) => i % 2 !== 0)),
      },
    ],
  };

  const handleFilterApply = (filters) => {
    const filtered = cctvs.filter((item) => {
      let matches = true;

      if (filters.cctvName) {
        matches = matches && item.cctv_name === filters.cctvName;
      }
      if (filters.ipAddress) {
        matches = matches && item.ip === filters.ipAddress;
      }
      if (filters.division) {
        matches = matches && item.division_name === filters.division;
      }
      if (filters.department) {
        matches = matches && item.department_name === filters.department;
      }
      if (filters.machine) {
        matches = matches && item.machine_name === filters.machine;
      }
      if (filters.status) {
        matches = matches && item.is_active === (filters.status === "active");
      }

      return matches;
    });

    setFilteredData(filtered);
  };

  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchText(val);
    const filtered = cctvs.filter((item) =>
      item.cctv_name.toLowerCase().includes(val.toLowerCase())
    );
    setFilteredData(filtered);
  };

  return (
    <div className="min-h-screen flex flex-col overflow-hidden">
      <div className="p-2 bg-white">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0 mb-1">
          <h1 className="text-xl font-semibold">Add New Camera</h1>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-3 w-full md:w-auto">
            <Input.Search
              placeholder="Search by Camera name"
              value={searchText}
              onChange={handleSearchChange}
              className="w-full sm:w-[250px]"
              allowClear
            />
            <div className="flex space-x-2">
              <Popover
                content={
                  <FiltersPopover
                    onApply={handleFilterApply}
                    dataSource={cctvs}
                  />
                }
                trigger="click"
                placement="bottomRight"
              >
                <Button icon={<FilterOutlined />} className="w-full sm:w-auto">
                  Filter
                </Button>
              </Popover>
              <Button
                type="primary"
                icon={<PlusOutlined />}
                onClick={() => navigate("/iot/pages/cctvmaster/create")}
                className="w-full sm:w-auto"
              >
                Add Camera
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 p-1 overflow-hidden">
        <div className="h-full overflow-auto rounded-lg border border-gray-200">
          <Table
            rowSelection={rowSelection}
            columns={columns}
            dataSource={filteredData.length > 0 ? filteredData : cctvs}
            loading={loading}
            rowKey="id"
            scroll={{ x: "max-content" }}
            pagination={{
              showSizeChanger: true,
              showTotal: (total) => `Total ${total} items`,
              position: ["bottomRight"],
              responsive: true,
            }}
            size="small"
            // components={{
            //   header: {
            //     cell: (props) => (
            //       <th
            //         {...props}
            //         style={{
            //           backgroundColor: primaryColor,
            //           color: contentBgColor,
            //           position: 'sticky',
            //           top: 0,
            //           zIndex: 2,
            //           padding: '12px 8px',
            //           whiteSpace: 'nowrap'
            //         }}
            //       />
            //     ),
            //   },
            // }}
            className="min-w-full"
          />
        </div>
      </div>
    </div>
  );
};

export default CCTVMasterPage;
