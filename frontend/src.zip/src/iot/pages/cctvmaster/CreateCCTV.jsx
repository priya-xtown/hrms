import React, { useState, useEffect } from 'react';
import { Form, Input, Select, Button, Space, message } from 'antd';
import { useNavigate, useLocation } from 'react-router-dom';
import { machineService } from '../../../ssms/services/Machineservices';
// import { cctvService } from '../../services/cctvService'; 

const { Option } = Select;

const CreateCCTV = () => {
  const { state } = useLocation();
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const [machines, setMachines] = useState([]);
  const [loading, setLoading] = useState(false);

  const isEdit = state?.isEdit;
  const pageTitle = isEdit ? 'Edit Camera' : 'Add New Camera';

  // Populate form fields if editing
  useEffect(() => {
    if (isEdit && state.initialValues) {
      form.setFieldsValue({
        cctv_name: state.initialValues.cctv_name,
        ip: state.initialValues.ip,
        machine_id: state.initialValues.machine_id,
        is_active: state.initialValues.is_active || 'active',
        cctv_description: state.initialValues.cctv_description,
      });
    }
  }, [form, isEdit, state]);

  // Fetch machines for the dropdown
  useEffect(() => {
    const fetchMachines = async () => {
      try {
        const res = await machineService.getMachines({ page: 1, limit: 1000 });
        if (Array.isArray(res?.data?.data)) {
          setMachines(res.data.data);
        } else {
          setMachines([]);
        }
      } catch (err) {
        message.error('Failed to load machines');
      }
    };
    fetchMachines();
  }, []);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const payload = {
        cctv_name: values.cctv_name,
        ip: values.ip,
        machine_id: Number(values.machine_id),
        is_active: values.is_active || 'active',
        cctv_description: values.cctv_description,
      };

      if (isEdit) {
        const response = await cctvService.updateCCTV(state.initialValues.id, payload);
        if (response.success) {
          message.success('Camera updated successfully');
          navigate('/iot/pages/cctvmaster');
        }
      } else {
        const response = await cctvService.createCCTV(payload);
        if (response.success) {
          message.success('Camera created successfully');
          navigate('/iot/pages/cctvmaster');
        }
      }
    } catch (error) {
      message.error(error.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-2 bg-white">
      <div className="max-w-8xl mx-auto">
        <h1 className="text-xl font-semibold mb-1">{pageTitle}</h1>

        <Form
          form={form}
          onFinish={handleSubmit}
          layout="vertical"
          className="space-y-4"
        >
          <div className="grid xs:grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            { !isEdit && (
              <>
                <Form.Item
                  name="cctv_name"
                  label="Camera Name"
                  rules={[{ required: true, message: 'Please enter Camera name' }]}
                >
                  <Input placeholder="Enter Camera name" className="rounded-lg" />
                </Form.Item>

                <Form.Item
                  name="ip"
                  label="IP Address"
                  rules={[{ required: true, message: 'Please enter IP address' }]}
                >
                  <Input placeholder="Enter IP address" className="rounded-lg" />
                </Form.Item>

                <Form.Item
                  name="machine_id"
                  label="Machine"
                  rules={[{ required: true, message: 'Please select machine' }]}
                >
                  <Select
                    showSearch
                    placeholder="Select machine"
                    optionFilterProp="children"
                    className="rounded-lg"
                    allowClear
                  >
                    {machines.map((machine) => (
                      <Option key={machine.id} value={machine.id}>
                        {machine.machine_name}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>

                <Form.Item name="cctv_description" label="Description">
                  <Input.TextArea
                    placeholder="Enter description"
                    className="rounded-lg"
                    rows={4}
                  />
                </Form.Item>
              </>
            )}

            { isEdit && (
              <Form.Item
                name="is_active"
                label="Status"
                rules={[{ required: true, message: 'Please select status' }]}
                initialValue="active"
              >
                <Select
                  placeholder="Select status"
                  className="rounded-lg"
                  allowClear
                  options={[
                    { value: 'active', label: 'Active' },
                    { value: 'inactive', label: 'Inactive' },
                  ]}
                />
              </Form.Item>
            )}
          </div>

          <Form.Item className="flex justify-end mt-6">
            <Space>
              <Button
                type="primary"
                danger
                onClick={() => navigate('/iot/pages/cctvmaster')}
                className="rounded-lg"
              >
                Cancel
              </Button>
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                className="rounded-lg"
              >
                {isEdit ? 'Update Camera' : 'Create CCTV'}
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default CreateCCTV;
