import { Routes, Route } from "react-router-dom";
import IotDashboard from "./pages/Dashboard";
import Report from "./pages/Report";
import Settings from "./pages/Settings";
import CreateCCTV from "./pages/cctvmaster/CreateCCTV";
import CCTVMasterPage from "./pages/cctvmaster/CCTVMaster";
import CreateSensor from "./pages/sensormaster/CreateSensor";
import SensorMaster from "./pages/sensormaster/SensorMaster";
import { EditOutlined, SettingOutlined, DatabaseOutlined,CameraOutlined  } from "@ant-design/icons";
export const iotMenuItems = [
  {
    icon: <EditOutlined />,
    key: "/iot/pages/report",
    label: "Report",
  },
  {
    icon: <SettingOutlined />,
    key: "/iot/pages/settings",
    label: "Settings",
  },
  {
    icon: <DatabaseOutlined />,
    key: "/iot/pages/sensormaster",
    label: "Sensor",
  },
  // {
  //   icon:<CameraOutlined />,
  //   key: "/iot/pages/cctvmaster",
  //   label: "Camera ",
  // },
];

const IOTRoutes = () => {
  return (
    <Routes>

      <Route path="pages/sensormaster/create" element={< CreateSensor />} />
      <Route path="pages/sensormaster" element={< SensorMaster />} />

      <Route path="pages/cctvmaster/create" element={< CreateCCTV />} />
      <Route path="pages/cctvmaster" element={< CCTVMasterPage />} />

      <Route path="pages/dashboard" element={<IotDashboard />} />
      <Route path="pages/report" element={<Report />} />
      <Route path="pages/settings" element={<Settings />} />


    </Routes>
  );
};

export default IOTRoutes;
