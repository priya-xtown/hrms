import { Routes, Route } from "react-router-dom";
import {
  TeamOutlined,
  SettingOutlined,
  ControlOutlined,
} from "@ant-design/icons";
// import { ControlOutlined} from "@ant-design/icons";
import SsmsDashboard from "./pages/Dashboard";
import LineController from "./pages/LineController";
import Controller from "./pages/ControllerMaster/controller";
import MachinePage from "./pages/Machinemaster/MachineMaster";
import CreateMachine from "./pages/Machinemaster/CreateMachine";
import ControllerForm from "./pages/ControllerMaster/Controllerform";
// import { Children } from "react";
// import Department from "./pages/DepartmentMaster/Department";
// import Party from "./pages/PartyMaster/Party";
// import Partyform from "./pages/PartyMaster/PartyForm";
// import DivisionPage from "./pages/divisionmaster/DivisionMaster";
// import RolePage from "./pages/Typemaster/EmployeeTypeMaster";

// import SensorMaster from "./pages/sensormaster/SensorMaster";
// import CreateSensor from "./pages/sensormaster/CreateSensor";

// import CCTVMasterPage from "./pages/cctvmaster/CCTVMaster";
// import CreateCCTV from "./pages/cctvmaster/CreateCCTV";

// import AlgorithmMasterPage from "./pages/algorithmmaster/AlgorithmMaster";
// import Stylemaster from "./pages/Stylemaster/stylemaster";
// import Partmaster from "./pages/PartMaster/Partmaster";
// import Colorcombo from "./pages/ColorComboMaster/Colorcombo";
// import OrderMasterPage from "./pages/Ordermaster/OrderMaster";

export const ssmsMenuItems = [
  {
    icon: <TeamOutlined />,
    key: "/ssms/pages/linecontroller",
    label: "Line Controller",
  },

  // {
  //   key: "/ssms/pages/party",
  //   label: "Party",
  // },
  // {
  //   key: "/ssms/pages/divisionmaster",
  //   label: "Division Master",
  // },
  // {
  //   key: "/ssms/pages/stylemaster",
  //   label: "Stylemaster",
  // },
  // {
  //   key: "/ssms/pages/colorcombo",
  //   label: "Colorcombo",
  // },
  // {
  //   key: "/ssms/pages/partMaster",
  //   label: "Partmaster",
  // },

  // {
  //   key: "/ssms/pages/typemaster",
  //   label: "Role Master",
  // },
  {
    icon: <SettingOutlined />,
    key: "/ssms/pages/Machinemaster",
    label: "Machine ",
  },

  {
    icon: <ControlOutlined />,

    key: "/ssms/pages/controller",
    label: "Controller",
  },
  // {
  //   key: "/ssms/pages/Sensormaster",
  //   label: "Sensor Master",
  // },
  // {
  //   key: "/ssms/pages/cctvmaster",
  //   label: "CCTV Master",
  // },
  // {
  //   key: "/ssms/pages/Algorithmmaster",
  //   label: "AlgorithmMaster",
  // },
  // {
  //   key: "/ssms/pages/Ordermaster",
  //   label: "OrderMaster",
  // },
];

const SSMSRoutes = () => {
  return (
    <Routes>
      <Route path="pages/dashboard" element={<SsmsDashboard />} />
      <Route path="pages/linecontroller" element={<LineController />} />
      <Route path="pages/createcontroller" element={<ControllerForm />} />
      <Route path="pages/controller" element={<Controller />} />
      <Route path="pages/machinemaster" element={<MachinePage />} />
      <Route path="pages/machinemaster/create" element={<CreateMachine />} />
      {/*    
      <Route path="pages/stylemaster" element={<Stylemaster />} />
      <Route path="pages/colorcombo" element={<Colorcombo />} /> */}
      {/* <Route path="pages/department" element={<Department />} />
      <Route path="pages/branch" element={<Branch />} /> */}

      {/* <Route path="pages/party" element={<Party />} />
      <Route path="pages/partycreate" element={<Partyform />} />
      <Route path="pages/partmaster" element={<Partmaster />} /> */}

      {/* <Route path="pages/divisionmaster" element={<DivisionPage />} /> */}
      {/* <Route path="pages/typemaster" element={<RolePage />} /> */}
      {/* <Route path="pages/sensormaster" element={<SensorMaster />} />
      <Route path="pages/sensormaster/create" element={<CreateSensor />} /> */}

      {/* <Route path="pages/cctvmaster" element={<CCTVMasterPage />} />
      <Route path="pages/cctvmaster/create" element={<CreateCCTV />} /> */}

      {/* <Route path="pages/Algorithmmaster" element={<AlgorithmMasterPage />} />

      <Route path="pages/Ordermaster" element={<OrderMasterPage />} /> */}
    </Routes>
  );
};

export default SSMSRoutes;
