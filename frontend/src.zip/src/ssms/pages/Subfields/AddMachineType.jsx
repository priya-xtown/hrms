// src/components/AddMachineType.jsx

import { useState, useEffect } from "react";
import {
  Card,
  Select,
  Button,
  Input,
  Row,
  Col,
  Space,
  Divider,
  Form,
  message,
} from "antd";
import {
  EditOutlined,
  DeleteOutlined,
  PlusOutlined,
  SaveOutlined,
  CloseOutlined,
} from "@ant-design/icons";
import { machineTypeService } from "../../services/machinetype";

const { Option } = Select;

const AddMachineType = () => {
  const [messageApi, contextHolder] = message.useMessage();
  const [machineTypes, setMachineTypes] = useState([]);
  const [selectedMachineTypeId, setSelectedMachineTypeId] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [form] = Form.useForm();

  useEffect(() => {
    fetchMachineTypes();
  }, []);

  const fetchMachineTypes = async () => {
    try {
      const response = await machineTypeService.getAllMachineTypes();
      if (response.success) {
        const list = Array.isArray(response.data.data)
          ? response.data.data
          : [];
        setMachineTypes(list);
        console.log("Machine types loaded:", response.data);
        
      } else {
        messageApi.error("Failed to load machine types");
        setMachineTypes([]);
      }
    } catch (err) {
      console.error("Error fetching machine types:", err);
      messageApi.error("Failed to load machine types");
      setMachineTypes([]);
    }
  };

  const onFinish = async (values) => {
    try {
      let response;
      // `values` now has shape { machine_type: "…" }
      if (isEditing && selectedMachineTypeId) {
        response = await machineTypeService.updateMachineType(
          selectedMachineTypeId,
          values
        );
      } else {
        response = await machineTypeService.createMachineType(values);
      }

      if (response.success) {
        await fetchMachineTypes();
        form.resetFields();
        setSelectedMachineTypeId("");
        setIsEditing(false);
      } else {
        messageApi.error("Operation did not succeed");
      }
    } catch (err) {
      console.error("Operation failed:", err);
      messageApi.error("An error occurred while saving");
    }
  };

  const handleEdit = async () => {
    if (!selectedMachineTypeId) {
      messageApi.error("Please select a machine type to edit");
      return;
    }

    try {
      const response = await machineTypeService.getMachineTypeById(
        selectedMachineTypeId
      );
      if (response.success && response.data) {

        const mt = response.data.data ? response.data.data : response.data;
        if (!mt) {
          messageApi.error("Machine type details not available");
          return;
        }
        form.setFieldsValue({
          machine_type: mt.machine_type,
        });
        setIsEditing(true);
      } else {
        messageApi.error("Failed to load machine type details");
      }
    } catch (error) {
      console.error("Edit error:", error);
      messageApi.error("Error loading machine type details");
    }
  };

  const handleDelete = async () => {
    if (!selectedMachineTypeId) return;

    try {
      const response = await machineTypeService.deleteMachineType(
        selectedMachineTypeId
      );
      if (response.success) {
        await fetchMachineTypes();
        form.resetFields();
        setSelectedMachineTypeId("");
        setIsEditing(false);
      } else {
        messageApi.error("Failed to delete machine type");
      }
    } catch (err) {
      console.error("Delete error:", err);
      messageApi.error("Error deleting machine type");
    }
  };

  const handleCancel = () => {
    form.resetFields();
    setSelectedMachineTypeId("");
    setIsEditing(false);
  };

  return (
    <>
      {contextHolder}
      <Card title="Machine Types" variant="plain" style={{ width: "35%" }}>
        <Space direction="vertical" style={{ width: "100%" }}>
          {/* Select existing machine type */}
          <Select
            placeholder={
              machineTypes.length === 0
                ? "No machine types available"
                : "Select a machine type"
            }
            style={{ width: "100%" }}
            value={selectedMachineTypeId || undefined}
            onChange={(val) => {
              setSelectedMachineTypeId(val);
              if (!isEditing) {
                form.resetFields();
              }
            }}
            disabled={machineTypes.length === 0}
          >
            {machineTypes.map((mt) => (
              <Option key={mt.id} value={mt.id.toString()}>
                {mt.machine_type}
              </Option>
            ))}
          </Select>

          <Row justify="space-between" style={{ width: "100%" }}>
            <Col>
              <Space>
                <Button
                  type="primary"
                  icon={<EditOutlined />}
                  onClick={handleEdit}
                  disabled={!selectedMachineTypeId}
                >
                  Edit
                </Button>
                <Button
                  danger
                  icon={<DeleteOutlined />}
                  onClick={handleDelete}
                  disabled={!selectedMachineTypeId}
                >
                  Delete
                </Button>
              </Space>
            </Col>
          </Row>

          <Divider />

          {/*
            Prevent nesting of <form> by using component={false} here.
          */}
          <Form
            form={form}
            layout="vertical"
            onFinish={onFinish}
            initialValues={{ machine_type: "" }}
            component={false}
          >
            <Form.Item
              name="machine_type"
              label="Machine Type"
              rules={[
                { required: true, message: "Please enter a machine type" },
              ]}
            >
              <Input placeholder="e.g. Hydraulic Press" />
            </Form.Item>

            <Form.Item>
              <Space>
                <Button
                  type="primary"
                  htmlType="submit"
                  onClick={() => {
                    form.validateFields().then(onFinish);
                  }}
                  icon={isEditing ? <SaveOutlined /> : <PlusOutlined />}
                >
                  {isEditing ? "Update Machine Type" : "Add Machine Type"}
                </Button>
                {isEditing && (
                  <Button icon={<CloseOutlined />} onClick={handleCancel}>
                    Cancel
                  </Button>
                )}
              </Space>
            </Form.Item>
          </Form>
        </Space>
      </Card>
    </>
  );
};

export default AddMachineType;
