import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Dropdown,
  Form,
  Input,
  Select,
  Row,
  Col,
  Modal,
  Popover,
  Menu,
  message,
} from "antd";

import {
  FilterOutlined,
  EllipsisOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import { EyeOutlined, DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useTheme } from "../../../context/ThemeContext";

const { Option } = Select;

const getUniqueValues = (data, key) =>
  [...new Set(data.map((item) => item[key]))].filter(Boolean);

const FiltersPopover = ({ onApply, dataSource, currentFilters }) => {
  const [filters, setFilters] = useState({
    status: currentFilters.status,
  });

  const statuses = getUniqueValues(dataSource, "status");

  const onChange = (field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const renderPopoverContent = (field, options) => (
    <div>
      <div style={{ marginBottom: 3, fontWeight: "bold", color: "#555" }}>
        {field.charAt(0).toUpperCase() + field.slice(1)}
      </div>
      <Select
        value={filters[field]}
        onChange={(val) => onChange(field, val)}
        placeholder={`Select ${field}`}
        style={{ width: 180 }}
        allowClear
      >
        {options.map((opt) => (
          <Option key={opt} value={opt}>
            {opt}
          </Option>
        ))}
      </Select>
    </div>
  );

  return (
    <div style={{ padding: 10, width: 200, height: "auto" }}>
      {["status"].map((field) => (
        <div style={{ marginBottom: 15 }}>
          <Popover
            content={renderPopoverContent("status", statuses)}
            trigger="hover"
            placement="right"
          >
            <div
              style={{
                cursor: "pointer",
                fontWeight: "bold",
                width: 100,
                color: filters.status ? "#1890ff" : "inherit",
              }}
            >
              Status
              {filters.status && (
                <span className="ml-2 text-xs text-gray-500">(1)</span>
              )}
            </div>
          </Popover>
        </div>
      ))}
      <div style={{ textAlign: "center", marginTop: 20 }} className="space-x-2">
        <Button
          danger
          size="small"
          onClick={() => {
            setFilters({});
            onApply({});
          }}
          disabled={Object.values(filters).every((val) => !val)}
        >
          Reset
        </Button>
        <Button
          type="primary"
          size="small"
          onClick={() => onApply(filters)}
          disabled={Object.values(filters).every((val) => !val)}
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const Stylemaster = () => {
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filteredData, setFilteredData] = useState([]);
  const [filters, setFilters] = useState({});
  const [form] = Form.useForm();
  const [hovered, setHovered] = useState(false);
  const { contentBgColor, primaryColor } = useTheme();
  const handleFormSubmit = (vals) => {
    console.log("Submitted:", vals);
    setIsModalOpen(false);
  };

  const applyFilters = (newFilters = filters, newSearchText = searchText) => {
    let fd = [...dataSource];
    if (newSearchText) {
      fd = fd.filter((item) =>
        (item.branch || "").toLowerCase().includes(newSearchText.toLowerCase())
      );
    }
    Object.entries(newFilters).forEach(([key, val]) => {
      if (val) {
        fd = fd.filter((item) => item[key] === val);
      }
    });
    setFilteredData(fd);
  };

  useEffect(() => {
    applyFilters();
  }, []);

  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchText(val);
    applyFilters(filters, val);
  };

  const handleFilterApply = (newFilters) => {
    setFilters(newFilters);
    applyFilters(newFilters, searchText);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: setSelectedRowKeys,
    selections: [
      Table.SELECTION_ALL,
      Table.SELECTION_INVERT,
      Table.SELECTION_NONE,
      {
        key: "odd",
        text: "Select Odd Row",
        onSelect: (changableRowKeys) =>
          setSelectedRowKeys(changableRowKeys.filter((_, i) => i % 2 === 0)),
      },
      {
        key: "even",
        text: "Select Even Row",
        onSelect: (changableRowKeys) =>
          setSelectedRowKeys(changableRowKeys.filter((_, i) => i % 2 !== 0)),
      },
    ],
  };
  const dataSource = [];

  const columns = [
    {
      title: "S.No",
      key: "serialNumber",
      width: 70,
      render: (_, __, index) => index + 1,
      fixed: "left",
    },

    { title: "StyleName", dataIndex: "stylename", key: "stylename" },
    { title: "Category", dataIndex: "category", key: "category" },
    { title: "FabricType", dataIndex: "fabrictype", key: "fabrictype" },
    { title: "Status", dataIndex: "status", key: "status" },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Dropdown
          overlay={
            <Menu onClick={(e) => console.log(`${e.key} clicked for`, record)}>
              <Menu.Item icon={<EyeOutlined />} key="view">
                View
              </Menu.Item>
              <Menu.Item icon={<EditOutlined />} key="edit">
                Edit
              </Menu.Item>
              <Menu.Item icon={<DeleteOutlined />} key="delete">
                Delete
              </Menu.Item>
            </Menu>
          }
          trigger={["click"]}
        >
          <EllipsisOutlined className="cursor-pointer text-lg rotate-90" />
        </Dropdown>
      ),
    },
  ];

  return (
    <div className="max-w-full overflow-hidden">
      <div className="bg-white">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-2">
          <h1 className="text-xl font-semibold">StyleMaster</h1>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
            <div className="w-full sm:w-[250px] min-w-[200px]">
              <Input.Search
                placeholder="Search by style"
                value={searchText}
                onChange={handleSearchChange}
                className="w-full"
                allowClear
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto justify-stretch sm:justify-end">
              <Popover
                content={
                  <FiltersPopover
                    dataSource={dataSource}
                    currentFilters={filters}
                    onApply={handleFilterApply}
                  />
                }
                trigger="click"
                placement="bottomLeft"
              >
                <Button
                  icon={<FilterOutlined />}
                  onMouseEnter={() => setHovered(true)}
                  onMouseLeave={() => setHovered(false)}
                >
                  Filters
                </Button>
              </Popover>
              <Button
                type="primary"
                icon={<PlusOutlined />}
                onClick={() => setIsModalOpen(true)}
              >
                Add Style
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="overflow-x-auto">
        <Table
          rowSelection={rowSelection}
          columns={columns}
          dataSource={filteredData}
          pagination={{
            pageSize: 10,
            responsive: true,
            showSizeChanger: true,
            showTotal: (total, range) =>
              `${range[0]}-${range[1]} of ${total} items`,
          }}
          rowKey="key"
          scroll={{ x: "max-content" }}
          size="small"
          // components={{
          //     header: {
          //         cell: (props) => (
          //             <th
          //                 {...props}
          //                 style={{
          //                     backgroundColor: primaryColor,
          //                     color: contentBgColor,
          //                     position: "sticky",
          //                     top: 0,
          //                     zIndex: 2,
          //                     padding: "12px 8px",
          //                     whiteSpace: "nowrap",
          //                 }}
          //             />
          //         ),
          //     },
          // }}
          className="min-w-full"
        />
      </div>
      <Modal
        title={<div className="text-xl font-semibold">Add Style</div>}
        open={isModalOpen}
        onCancel={() => setIsModalOpen(false)}
        footer={null}
        width={800}
        style={{ top: 20 }}
      >
        <Form
          layout="vertical"
          form={form}
          onFinish={handleFormSubmit}
          initialValues={{ status: "Active" }}
          className="w-full"
        >
          <Row gutter={[16, 16]}>
            <Col xs={24} sm={12}>
              <Form.Item
                name="name"
                label="Style Name"
                rules={[
                  { required: true, message: "Please enter the style name" },
                ]}
              >
                <Input placeholder="Enter Style Name" allowClear />
              </Form.Item>
            </Col>

            <Col xs={24} sm={12}>
              <Form.Item
                name="category"
                label="Category"
                rules={[
                  { required: true, message: "Please enter the category" },
                ]}
              >
                <Input placeholder="Enter Category" allowClear />
              </Form.Item>
            </Col>

            <Col xs={24} sm={12}>
              <Form.Item
                name="fabric_type"
                label="Fabric Type"
                rules={[
                  { required: true, message: "Please enter the fabric type" },
                ]}
              >
                <Input placeholder="Enter Fabric Type" allowClear />
              </Form.Item>
            </Col>

            <Col xs={24} sm={12}>
              <Form.Item
                name="status"
                label="Status"
                rules={[{ required: true }]}
              >
                <Select placeholder="Select status" allowClear>
                  {getUniqueValues(dataSource, "status").map((s) => (
                    <Select.Option key={s} value={s}>
                      {s}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>

            {/* Wrap description in a Col to control width */}
            <Col xs={24}>
              <Form.Item name="description" label="Description">
                <Input.TextArea rows={2} placeholder="Enter description" />
              </Form.Item>
            </Col>
          </Row>

          <div className="flex flex-col sm:flex-row justify-end gap-2 mt-4">
            <Button
              type="primary"
              danger
              onClick={() => setIsModalOpen(false)}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              className="w-full sm:w-auto"
            >
              Submit
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default Stylemaster;
