import React, { useState, useEffect } from "react";
import { Form, Input, Select, Row, Col, Button, message } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import { controllerService } from "../../services/Controller";
import { departmentService } from "../../../company/services/departmentService";
import { companyService } from "../../../company/services/CompanyServices";
import { branchServices } from "../../../company/services/CompanyServices";
import { divisionService } from "../../../company/services/divisionService";

const { Option } = Select;

const ControllerForm = () => {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const location = useLocation();

  const { isEdit = false, initialValues = {} } = location.state || {};
  const [messageApi, contextHolder] = message.useMessage();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [department, setDepartment] = useState([]);
  const [company, setCompany] = useState([]);
  const [division, setDivision] = useState([]);
  const [branch, setBranch] = useState([]);

  // Fetch data for dropdowns
  const fetchDepartment = async () => {
    try {
      const response = await departmentService.getAllDepartments();
      setDepartment(response.data || []);
    } catch (error) {
      messageApi.error("Failed to fetch departments");
      console.error("Fetch departments error:", error);
    }
  };

  const fetchCompany = async () => {
    try {
      const response = await companyService.getCompany();
      setCompany(response.data || []);
    } catch (error) {
      messageApi.error("Failed to fetch companies");
      console.error("Fetch companies error:", error);
    }
  };

  const fetchDivision = async () => {
    try {
      const response = await divisionService.getAllDivisions();
      setDivision(response.data || []);
    } catch (error) {
      messageApi.error("Failed to fetch divisions");
      console.error("Fetch divisions error:", error);
    }
  };

  const fetchBranch = async () => {
    try {
      const response = await branchServices.getBranch();
      setBranch(response.data || []);
    } catch (error) {
      messageApi.error("Failed to fetch branches");
      console.error("Fetch branches error:", error);
    }
  };

  useEffect(() => {
    fetchDepartment();
    fetchCompany();
    fetchDivision();
    fetchBranch();
  }, []);

  // Populate form in edit mode
  useEffect(() => {
    if (isEdit && initialValues && Object.keys(initialValues).length) {
      form.setFieldsValue({
        Linename: initialValues.line_name,
        ipAddress: initialValues.ip_address,
        location: initialValues.location,
        // companyId: initialValues.company_id,
        // divisionId: initialValues.division_id,
        // branchId: initialValues.branch_id,
        // departmentId: initialValues.department_id,
        status: initialValues.status
          ? initialValues.status.charAt(0).toUpperCase() +
            initialValues.status.slice(1)
          : "Active",
      });
    }
  }, [isEdit, initialValues, form]);

  const handleFormSubmit = async (values) => {
    setIsSubmitting(true);
    const data = {
      line_name: values.Linename,
      ip_address: values.ipAddress,
      location: values.location,
      // company_id: values.companyId,
      // division_id: values.divisionId,
      // branch_id: values.branchId,
      // department_id: values.departmentId,
      status: isEdit ? values.status?.toLowerCase() : "active", // Default to 'active' for add
    };

    try {
      if (isEdit) {
        await controllerService.updateController(initialValues.id, data);
        messageApi.success("Controller updated successfully");
      } else {
        await controllerService.createController(data);
        messageApi.success("Controller created successfully");
      }
      form.resetFields();
      navigate("/ssms/pages/controller", {
        state: {
          message: isEdit
            ? "Controller updated successfully"
            : "Controller created successfully",
        },
      });
    } catch (error) {
      messageApi.error(`Operation failed: ${error.message || "Unknown error"}`);
      console.error("Controller operation failed:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      {contextHolder}
      <div className="max-w-8xl mx-auto rounded p-6">
        <h2 className="text-xl font-semibold mb-4">
          {isEdit ? "Edit Controller" : "Add Controller"}
        </h2>
        <Form
          layout="vertical"
          form={form}
          onFinish={handleFormSubmit}
          initialValues={{ status: "Active" }}
          className="w-full"
        >
          <Row gutter={[16, 16]}>
            <Col xs={24} sm={12}>
              <Form.Item
                name="Linename"
                label="Line Name"
                rules={[{ required: true, message: "Please enter line name" }]}
              >
                <Input placeholder="Enter line name" />
              </Form.Item>
            </Col>

            {/* Commented-out fields remain unchanged */}
            {/* <Col xs={24} sm={12}>
                            <Form.Item
                                name="departmentId"
                                label="Department"
                                rules={[{ required: true, message: 'Please select department' }]}
                            >
                                <Select placeholder="Select department" allowClear>
                                    {department?.departments?.map((dept) => (
                                        <Option key={dept.id} value={dept.id}>
                                            {dept.name}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>

                        <Col xs={24} sm={12}>
                            <Form.Item
                                name="branchId"
                                label="Branch"
                                rules={[{ required: true, message: 'Please select branch' }]}
                            >
                                <Select placeholder="Select branch" allowClear>
                                    {branch?.data?.branches?.map((branchItem) => (
                                        <Option key={branchItem.id} value={branchItem.id}>
                                            {branchItem.name}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>

                        <Col xs={24} sm={12}>
                            <Form.Item
                                name="divisionId"
                                label="Division"
                                rules={[{ required: true, message: 'Please select division' }]}
                            >
                                <Select placeholder="Select division" allowClear>
                                    {division?.divisions?.map((div) => (
                                        <Option key={div.id} value={div.id}>
                                            {div.name}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>

                        <Col xs={24} sm={12}>
                            <Form.Item
                                name="companyId"
                                label="Company"
                                rules={[{ required: true, message: 'Please select company' }]}
                            >
                                <Select placeholder="Select company" allowClear>
                                    {company?.data?.map((c) => (
                                        <Option key={c.id} value={c.id}>
                                            {c.name}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col> */}

            <Col xs={24} sm={12}>
              <Form.Item
                name="ipAddress"
                label="IP Address"
                rules={[
                  { required: true, message: "Please enter an IP address" },
                  {
                    pattern:
                      /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/,
                    message: "Enter a valid IPv4 address",
                  },
                ]}
              >
                <Input placeholder="Enter IP address" />
              </Form.Item>
            </Col>

            <Col xs={24} sm={12}>
              <Form.Item
                name="location"
                label="Location"
                rules={[{ required: true, message: "Please enter location" }]}
              >
                <Input placeholder="Enter location" />
              </Form.Item>
            </Col>

            {/* Status field shown only in edit mode */}
            {isEdit && (
              <Col xs={24} sm={12}>
                <Form.Item
                  name="status"
                  label="Status"
                  rules={[{ required: true, message: "Please select status" }]}
                >
                  <Select placeholder="Select status" allowClear>
                    <Option value="Active">Active</Option>
                    <Option value="Inactive">Inactive</Option>
                  </Select>
                </Form.Item>
              </Col>
            )}
          </Row>

          <div className="flex flex-col sm:flex-row justify-end gap-2 mt-4">
            <Button
            danger
              onClick={() => navigate("/ssms/pages/controller")}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              loading={isSubmitting}
              className="w-full sm:w-auto"
            >
              {isEdit ? "Update" : "Submit"}
            </Button>
          </div>
        </Form>
      </div>
    </>
  );
};

export default ControllerForm;
