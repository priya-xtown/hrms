const LineController = () => {
  return (
    <div>
      <h1>Line Controller</h1>
      <p>This is the Line Controller page.</p>
    </div>
  );
};
export default LineController;