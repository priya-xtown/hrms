import React, { useState, useEffect } from 'react';
import {
    Table,
    Dropdown,
    Menu,
    Input,
    Popover,
    Button,
    Select,
    message,
    Tag,
} from 'antd';
import {
    EyeOutlined,
    EditOutlined,
    DeleteOutlined,
    FilterOutlined,
    EllipsisOutlined,
    PlusOutlined,
} from '@ant-design/icons';
import { useTheme } from '../../../context/ThemeContext';
import { useNavigate, useLocation } from 'react-router-dom';

const { Option } = Select;

const getUniqueValues = (data, key) => [...new Set(data.map((item) => item[key]))].filter(Boolean);

const FiltersPopover = ({ onApply, dataSource, currentFilters }) => {
  const [filters, setFilters] = useState({ ...currentFilters });

  const statuses = getUniqueValues(dataSource, "status");

  const onChange = (field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const renderPopoverContent = (field) => {
    let options = [];
    if (field === "status") options = statuses;

    return (
      <div>
        <div style={{ marginBottom: 3, fontWeight: "bold", color: "#555" }}>
          {field.charAt(0).toUpperCase() + field.slice(1)}

    const onChange = (field, value) => {
        setFilters((prev) => ({
            ...prev,
            [field]: value,
        }));
    };

    const renderPopoverContent = (field) => {
        let options = [];
        if (field === "status") options = statuses;

        return (
            <div>
                <div style={{ marginBottom: 3, fontWeight: 'bold', color: '#555' }}>
                    {field.charAt(0).toUpperCase() + field.slice(1)}
                </div>
                <Select
                    value={filters[field]}
                    onChange={(val) => onChange(field, val)}
                    placeholder={`Select ${field}`}
                    style={{ width: 180 }}
                    allowClear
                >
                    {options.map((opt) => (
                        <Option key={opt} value={opt}>
                            {opt}
                        </Option>
                    ))}
                </Select>
            </div>
        );
    };

    return (
        <div style={{ padding: 10, width: 200 }}>
            {['status'].map((field) => (
                <div key={field} style={{ marginBottom: 15 }}>
                    <Popover
                        content={renderPopoverContent(field)}
                        trigger="hover"
                        placement="right"
                    >
                        <div
                            style={{
                                cursor: 'pointer',
                                fontWeight: 'bold',
                                width: 100,
                                color: filters[field] ? '#1890ff' : 'inherit',
                            }}
                        >
                            {field.charAt(0).toUpperCase() + field.slice(1)}
                            {filters[field] && <span className="ml-2 text-xs text-gray-500">(1)</span>}
                        </div>
                    </Popover>
                </div>
            ))}
            <div className="text-center space-x-2 mt-2">
                <Button
                    danger
                    size="small"
                    onClick={() => {
                        setFilters({});
                        onApply({});
                    }}
                    disabled={Object.values(filters).every((val) => !val)}
                >
                    Reset
                </Button>
                <Button
                    type="primary"
                    size="small"
                    onClick={() => onApply(filters)}
                    disabled={Object.values(filters).every((val) => !val)}
                >
                    Apply
                </Button>
            </div>
        </div>
        <Select
          value={filters[field]}
          onChange={(val) => onChange(field, val)}
          placeholder={`Select ${field}`}
          style={{ width: 180 }}
          allowClear
        >
          {options.map((opt) => (
            <Option key={opt} value={opt}>
              {opt}
            </Option>
          ))}
        </Select>
      </div>
    );
  };

  return (
    <div style={{ padding: 10, width: 200 }}>
      {["status"].map((field) => (
        <div key={field} style={{ marginBottom: 15 }}>
          <Popover
            content={renderPopoverContent(field)}
            trigger="hover"
            placement="right"
          >
            <div
              style={{
                cursor: "pointer",
                fontWeight: "bold",
                width: 100,
                color: filters[field] ? "#1890ff" : "inherit",
              }}
            >
              {field.charAt(0).toUpperCase() + field.slice(1)}
              {filters[field] && (
                <span className="ml-2 text-xs text-gray-500">(1)</span>
              )}
            </div>
          </Popover>
        </div>
      ))}
      <div className="text-center space-x-2 mt-2">
        <Button
          danger
          size="small"
          onClick={() => {
            setFilters({});
            onApply({});
          }}
          disabled={Object.values(filters).every((val) => !val)}
        >
          Reset
        </Button>
        <Button
          type="primary"
          size="small"
          onClick={() => onApply(filters)}
          disabled={Object.values(filters).every((val) => !val)}
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const initialDataSource = [
  {
    key: 1,
    partyname: "party1",
    phone: "9876543210",
    email: "party@xtown.in",
    address: "covai",
    partytype: "customers1",
    gstnumber: "9876543218990",
    contact: "13456678998",
    status: "Active",
  },
  {
    key: 2,
    partyname: "party2",
    phone: "9876543219",
    email: "party@xtown.in",
    address: "covai",
    partytype: "customers1",
    gstnumber: "9876543218990",
    contact: "34567890678",
    status: "Active",
  },
  {
    key: 3,
    partyname: "party3",
    phone: "9876543210",
    email: "party@xtown.in",
    address: "covai",
    partytype: "vendors",
    gstnumber: "9876543218990",
    contact: "98765432123",
    status: "Inactive",
  },
];

const Party = () => {
  const [searchText, setSearchText] = useState("");
  const [filters, setFilters] = useState({});
  const [filteredData, setFilteredData] = useState(initialDataSource);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [pagination, setPagination] = useState({ current: 1, pageSize: 10 });

  const { primaryColor, contentBgColor } = useTheme();
  const navigate = useNavigate();

  const applyFilters = (f = filters, text = searchText) => {
    let data = initialDataSource;

    if (text) {
      data = data.filter((item) =>
        Object.values(item).some((val) =>
          String(val).toLowerCase().includes(text.toLowerCase())
        )
      );
    }

    Object.entries(f).forEach(([key, value]) => {
      if (value) {
        data = data.filter((item) => item[key] === value);
      }
    });

    setFilteredData(data);
  };

  useEffect(() => {
    applyFilters();
  }, []);

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchText(value);
    applyFilters(filters, value);
  };

  const handleFilterApply = (newFilters) => {
    setFilters(newFilters);
    applyFilters(newFilters, searchText);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: setSelectedRowKeys,
  };

  const columns = [
    {
      title: "S.No",
      key: "serialNumber",
      width: 70,
      render: (_text, _record, index) =>
        (pagination.current - 1) * pagination.pageSize + index + 1,
    },
    { title: "Partyname", dataIndex: "partyname", key: "partyname" },
    { title: "Phone", dataIndex: "phone", key: "phone" },
    { title: "Email", dataIndex: "email", key: "email" },
    { title: "Address", dataIndex: "address", key: "address" },
    { title: "PartyType", dataIndex: "partytype", key: "partytype" },
    { title: "Gst-number", dataIndex: "gstnumber", key: "gstnumber" },
    { title: "Contact-person", dataIndex: "contact", key: "contact" },
    { title: "Status", dataIndex: "status", key: "status" },
    {
        key: 3,
        partyname: 'party3',
        phone: '9876543210',
        email: 'party3@xtown.in',
        address: 'covai',
        partytype: 'vendors',
        gstnumber: '33CCCCC1234C1Z5',
        contact: '98765432123',
        status: 'inactive',
    },
];

const Party = () => {
    const [searchText, setSearchText] = useState('');
    const [filters, setFilters] = useState({});
    const [filteredData, setFilteredData] = useState(initialDataSource);
    const [selectedRowKeys, setSelectedRowKeys] = useState([]);
    const [pagination, setPagination] = useState({ current: 1, pageSize: 10 });
    const [messageApi, contextHolder] = message.useMessage();
    const { primaryColor, contentBgColor } = useTheme();
    const navigate = useNavigate();
    const location = useLocation();

    // Handle success messages from navigation
    useEffect(() => {
        if (location.state?.message) {
            messageApi.success(location.state.message);
            const { message, ...rest } = location.state;
            window.history.replaceState({ ...rest }, document.title);
        }
    }, [location.state, messageApi]);

    const applyFilters = (f = filters, text = searchText) => {
        let data = initialDataSource;

        if (text) {
            data = data.filter((item) =>
                Object.values(item).some((val) =>
                    String(val).toLowerCase().includes(text.toLowerCase())
                )
            );
        }

        Object.entries(f).forEach(([key, value]) => {
            if (value) {
                data = data.filter((item) => item[key].toLowerCase() === value.toLowerCase());
            }
        });

        setFilteredData(data);
    };

    useEffect(() => {
        applyFilters();
    }, []);

    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchText(value);
        applyFilters(filters, value);
    };

    const handleFilterApply = (newFilters) => {
        setFilters(newFilters);
        applyFilters(newFilters, searchText);
    };

    const handleMenuClick = (record, e) => {
        if (e.key === 'edit') {
            navigate('/ssms/pages/partycreate', {
                state: { isEdit: true, initialValues: record },
            });
        } else if (e.key === 'delete') {
            console.log('Delete:', record);
            messageApi.success('Party deleted successfully');
            // Simulate delete by filtering out the record
            setFilteredData((prev) => prev.filter((item) => item.key !== record.key));
        } else if (e.key === 'view') {
            console.log('View:', record);
        }
    };

    const rowSelection = {
        selectedRowKeys,
        onChange: setSelectedRowKeys,
    };

    const columns = [
        {
            title: 'S.No',
            key: 'serialNumber',
            width: 70,
            render: (_text, _record, index) =>
                (pagination.current - 1) * pagination.pageSize + index + 1,
        },
        {
            title: 'Party Name',
            dataIndex: 'partyname',
            key: 'partyname',
            render: (name) => (name ? name.charAt(0).toUpperCase() + name.slice(1) : ''),
        },
        { title: 'Phone', dataIndex: 'phone', key: 'phone' },
        { title: 'Email', dataIndex: 'email', key: 'email' },
        {
            title: 'Address',
            dataIndex: 'address',
            key: 'address',
            render: (name) => (name ? name.charAt(0).toUpperCase() + name.slice(1) : ''),
        },
        {
            title: 'Party Type',
            dataIndex: 'partytype',
            key: 'partytype',
            render: (name) => (name ? name.charAt(0).toUpperCase() + name.slice(1) : ''),
        },
        { title: 'GST Number', dataIndex: 'gstnumber', key: 'gstnumber' },
        { title: 'Contact Person', dataIndex: 'contact', key: 'contact' },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            render: (status) => {
                const label = status ? status.charAt(0).toUpperCase() + status.slice(1) : '';
                return (
                    <Tag color={status?.toLowerCase() === 'active' ? 'green' : 'red'}>
                        {label}
                    </Tag>
                );
            },
        },
        {
            title: 'Actions',
            key: 'actions',
            render: (_, record) => (
                <Dropdown
                    overlay={
                        <Menu onClick={(e) => handleMenuClick(record, e)}>
                            <Menu.Item key="view" icon={<EyeOutlined />}>
                                View
                            </Menu.Item>
                            <Menu.Item key="edit" icon={<EditOutlined />}>
                                Edit
                            </Menu.Item>
                            <Menu.Item key="delete" icon={<DeleteOutlined />}>
                                Delete
                            </Menu.Item>
                        </Menu>
                    }
                    trigger={['click']}
                >
                    <EllipsisOutlined style={{ fontSize: 18, cursor: 'pointer' }} rotate={90} />
                </Dropdown>
            ),
        },
    ];

    return (
        <>
            {contextHolder}
            <div className="max-w-full overflow-hidden">
                <div className="bg-white">
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-2">
                        <h2 className="font-semibold text-xl">Party Master</h2>
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
                            <Input.Search
                                placeholder="Search..."
                                value={searchText}
                                onChange={handleSearchChange}
                                allowClear
                            />
                            <Popover
                                content={
                                    <FiltersPopover
                                        dataSource={initialDataSource}
                                        currentFilters={filters}
                                        onApply={handleFilterApply}
                                    />
                                }
                                trigger="click"
                                placement="bottomLeft"
                            >
                                <Button icon={<FilterOutlined />}>Filters</Button>
                            </Popover>
                            <Button
                                type="primary"
                                icon={<PlusOutlined />}
                                onClick={() => navigate('/ssms/pages/partycreate')}
                            >
                                Add Party
                            </Button>
                        </div>
                    </div>

                    <Table
                        rowSelection={rowSelection}
                        columns={columns}
                        dataSource={filteredData}
                        pagination={{
                            ...pagination,
                            showSizeChanger: true,
                            showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
                        }}
                        onChange={(pag) => setPagination(pag)}
                        rowKey="key"
                        scroll={{ x: 'max-content' }}
                        components={{
                            header: {
                                cell: (props) => (
                                    <th
                                        {...props}
                                        style={{
                                            backgroundColor: primaryColor,
                                            color: contentBgColor,
                                            whiteSpace: 'nowrap',
                                            position: 'sticky',
                                            top: 0,
                                            zIndex: 1,
                                        }}
                                    />
                                ),
                            },
                        }}
                    />
                </div>
            </div>
        </>
    );
};

export default Party;