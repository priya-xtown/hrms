import React, { useState } from "react";
import { Form, Input, Select, Row, Col, Button, Space } from "antd";
import { useNavigate } from "react-router-dom";

const filterFields = [];

const Partyform = () => {
    const [form] = Form.useForm();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const navigate = useNavigate();


    const emptyRow = filterFields.reduce((obj, field) => {
        obj[field] = "";
        return obj;
    }, {});


    const dataSource = [{ ...emptyRow }, { ...emptyRow }];

    console.log(dataSource);

    const getFieldOptions = (field) => {
        return [...new Set(dataSource.map(item => item[field]))];
    };


    const optionsMap = filterFields.reduce((acc, field) => {
        acc[field] = getFieldOptions(field);
        return acc;
    }, {});


    const handleAddSubmit = async (values) => {
        setIsSubmitting(true);
        console.log("Form Submitted:", values);
        await new Promise(res => setTimeout(res, 1000));
        form.resetFields();
        setIsSubmitting(false);

        navigate("/ssms/pages/employee");
    };
    /*main component*/
    return (
        <div className=" max-w-8xl mx-auto  rounded">
            <h2 className="text-xl font-semibold mb-4">Add Party</h2>
            <Form
                form={form}
                layout="vertical"
                onFinish={handleAddSubmit}
                initialValues={{ status: "Active" }}
            >
                <Row gutter={[16, 16]}>
                    <Col xs={24} sm={12}>
                        <Form.Item
                            name="partyname"
                            label="Party Name"
                            rules={[{ required: true }]}
                        >
                            <Input placeholder="partyname" />
                        </Form.Item>
                    </Col>

                    <Col xs={24} sm={12}>
                        <Form.Item
                            name="email"
                            label="Email"
                            rules={[{ required: true }]}
                        >
                            <Input placeholder="Email is required" />
                        </Form.Item>
                    </Col>

                    <Col xs={24} sm={12}>
                        <Form.Item
                            name="gstnumber"
                            label="GST Number"
                            rules={[{ required: true, pattern: /^\d{10}$/ }]}
                        >
                            <Input placeholder="15-digit GST number" />
                        </Form.Item>
                    </Col>

                    <Col xs={24} sm={12}>
                        <Form.Item
                            name="phone"
                            label="Phone"
                            rules={[{ required: true, pattern: /^\d{10}$/ }]}
                        >
                            <Input placeholder="10-digit phone" />
                        </Form.Item>
                    </Col>

                    <Col xs={24} sm={12}>
                        <Form.Item
                            name="address"
                            label="Address"
                            rules={[{ required: true }]}
                        >
                            <Input.TextArea rows={2} placeholder="Address" />
                        </Form.Item>
                    </Col>

                    {/* Contact Person */}
                    <Col xs={24} sm={12}>
                        <Form.Item
                            name="contact_person"
                            label="Contact Person"
                            rules={[{ required: true }]}
                        >
                            <Input placeholder="Enter contact person name" />
                        </Form.Item>
                    </Col>

                    {/* Status */}
                    <Col xs={24} sm={12}>
                        <Form.Item
                            name="status"
                            label="Status"
                            rules={[{ required: true }]}
                        >
                            <Select placeholder="Select status">
                                <Select.Option value="Active">Active</Select.Option>
                                <Select.Option value="Inactive">Inactive</Select.Option>
                            </Select>
                        </Form.Item>
                    </Col>

                    {/* Dynamic Fields (if any) */}
                    {filterFields.map((field) => (
                        <Col xs={24} sm={12} key={field}>
                            <Form.Item
                                name={field}
                                label={field.charAt(0).toUpperCase() + field.slice(1)}
                                rules={[{ required: true }]}
                            >
                                <Select
                                    placeholder={`Select ${field}`}
                                    showSearch
                                    filterOption={(input, option) =>
                                        option.children.toLowerCase().includes(input.toLowerCase())
                                    }
                                >
                                    {optionsMap[field].map((opt) => (
                                        <Select.Option key={opt} value={opt}>
                                            {opt}
                                        </Select.Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>
                    ))}
                </Row>

                <Form.Item className="flex justify-end mt-6">
                    <Space>
                        <Button
                            type="primary"
                            danger
                            onClick={() => navigate('/ssms/pages/party')}
                        >
                            Cancel
                        </Button>
                        <Button type="primary" htmlType="submit" loading={isSubmitting}>
                            {isSubmitting ? 'Adding...' : 'Add Employee'}
                        </Button>
                    </Space>
                </Form.Item>
            </Form>

        </div>
    );
};

export default Partyform;