import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Dropdown,
  Form,
  Input,
  Select,
  Row,
  Col,
  Modal,
  Popover,
  Menu,
} from "antd";
import {
  FilterOutlined,
  EllipsisOutlined,
  PlusOutlined,
  EyeOutlined,
  DeleteOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { useTheme } from "../../../context/ThemeContext";

const { Option } = Select;

const getUniqueValues = (data, key) =>
  [...new Set(data.map((item) => item[key]))].filter(Boolean);

const FiltersPopover = ({ onApply, dataSource, currentFilters }) => {
  const [filters, setFilters] = useState({ status: currentFilters.status });

  const statuses = getUniqueValues(dataSource, "status");

  const renderPopoverContent = (field, options) => (
    <>
      <div className="font-medium mb-2">
        {field.charAt(0).toUpperCase() + field.slice(1)}
      </div>
      <Select
        value={filters[field]}
        onChange={(val) => setFilters({ ...filters, [field]: val })}
        placeholder={`Select ${field}`}
        style={{ width: 180 }}
        allowClear
      >
        {options.map((opt) => (
          <Option key={opt} value={opt}>
            {opt}
          </Option>
        ))}
      </Select>
    </>
  );

  return (
    <div className="p-3 w-[200px]">
      <div className="mb-4">
        <Popover
          content={renderPopoverContent("status", statuses)}
          trigger="hover"
          placement="right"
        >
          <div
            className={`cursor-pointer font-semibold ${
              filters.status ? "text-blue-500" : ""
            }`}
          >
            Status
            {filters.status && (
              <span className="ml-1 text-xs text-gray-500">(1)</span>
            )}
          </div>
        </Popover>
      </div>
      <div className="text-center space-x-2">
        <Button
          danger
          size="small"
          onClick={() => {
            setFilters({});
            onApply({});
          }}
          disabled={Object.values(filters).every((val) => !val)}
        >
          Reset
        </Button>
        <Button
          type="primary"
          size="small"
          onClick={() => onApply(filters)}
          disabled={Object.values(filters).every((val) => !val)}
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const Colorcombo = () => {
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filteredData, setFilteredData] = useState([]);
  const [filters, setFilters] = useState({});
  const [form] = Form.useForm();
  const { contentBgColor, primaryColor } = useTheme();

  const dataSource = []; // Replace with actual data

  const handleFormSubmit = (vals) => {
    console.log("Submitted:", vals);
    setIsModalOpen(false);
    form.resetFields();
  };

  const applyFilters = (newFilters = filters, newSearchText = searchText) => {
    let fd = [...dataSource];
    if (newSearchText) {
      fd = fd.filter((item) =>
        (item.comboname || "")
          .toLowerCase()
          .includes(newSearchText.toLowerCase())
      );
    }
    Object.entries(newFilters).forEach(([key, val]) => {
      if (val) {
        fd = fd.filter((item) => item[key] === val);
      }
    });
    setFilteredData(fd);
  };

  useEffect(() => {
    applyFilters();
  }, []);

  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchText(val);
    applyFilters(filters, val);
  };

  const handleFilterApply = (newFilters) => {
    setFilters(newFilters);
    applyFilters(newFilters, searchText);
  };

  const columns = [
    {
      title: "S.No",
      key: "serialNumber",
      width: 70,
      render: (_, __, index) => index + 1,
      fixed: "left",
    },
    { title: "Combo Name", dataIndex: "comboname", key: "comboname" },
    { title: "Primary Color", dataIndex: "primarycolor", key: "primarycolor" },
    {
      title: "Secondary Color",
      dataIndex: "secondarycolor",
      key: "secondarycolor",
    },
    { title: "Accent Color", dataIndex: "accentcolor", key: "accentcolor" },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Dropdown
          overlay={
            <Menu onClick={({ key }) => console.log(`${key} clicked`, record)}>
              <Menu.Item icon={<EyeOutlined />} key="view">
                View
              </Menu.Item>
              <Menu.Item icon={<EditOutlined />} key="edit">
                Edit
              </Menu.Item>
              <Menu.Item icon={<DeleteOutlined />} key="delete">
                Delete
              </Menu.Item>
            </Menu>
          }
          trigger={["click"]}
        >
          <EllipsisOutlined className="cursor-pointer text-lg rotate-90" />
        </Dropdown>
      ),
    },
  ];

  const rowSelection = {
    selectedRowKeys,
    onChange: setSelectedRowKeys,
    selections: [
      Table.SELECTION_ALL,
      Table.SELECTION_INVERT,
      Table.SELECTION_NONE,
    ],
  };

  return (
    <div className="max-w-full overflow-hidden">
      <div className="bg-white">
        <div className="flex flex-col sm:flex-row justify-between items-start mb-4 sm:items-center gap-3">
          <h1 className="text-xl font-semibold">Color Combo Master</h1>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <Input.Search
              placeholder="Search by color"
              value={searchText}
              onChange={handleSearchChange}
              className="w-full sm:w-[250px]"
              allowClear
            />
            <Popover
              content={
                <FiltersPopover
                  dataSource={dataSource}
                  currentFilters={filters}
                  onApply={handleFilterApply}
                />
              }
              trigger="click"
              placement="bottomLeft"
            >
              <Button icon={<FilterOutlined />}>Filters</Button>
            </Popover>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => setIsModalOpen(true)}
            >
              Add Color
            </Button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table
          rowSelection={rowSelection}
          columns={columns}
          dataSource={filteredData}
          pagination={{
            pageSize: 10,
            responsive: true,
            showSizeChanger: true,
            showTotal: (total, range) =>
              `${range[0]}-${range[1]} of ${total} items`,
          }}
          rowKey="key"
          scroll={{ x: "max-content" }}
          size="small"
          // components={{
          //     header: {
          //         cell: (props) => (
          //             <th
          //                 {...props}
          //                 style={{
          //                     backgroundColor: primaryColor,
          //                     color: contentBgColor,
          //                     position: "sticky",
          //                     top: 0,
          //                     zIndex: 2,
          //                     padding: "12px 8px",
          //                     whiteSpace: "nowrap",
          //                 }}
          //             />
          //         ),
          //     },
          // }}
          className="min-w-full"
        />
      </div>

      <Modal
        title={<div className="text-xl font-semibold">Add Color</div>}
        open={isModalOpen}
        onCancel={() => setIsModalOpen(false)}
        footer={null}
        width={800}
        style={{ top: 20 }}
      >
        <Form
          layout="vertical"
          form={form}
          onFinish={handleFormSubmit}
          className="w-full"
        >
          <Row gutter={[16, 16]}>
            <Col xs={24} sm={12}>
              <Form.Item
                name="comboname"
                label="Combo Name"
                rules={[
                  { required: true, message: "Please enter the combo name" },
                ]}
              >
                <Input placeholder="Enter combo name" allowClear />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item
                name="primarycolor"
                label="Primary Color"
                rules={[
                  { required: true, message: "Please enter the primary color" },
                ]}
              >
                <Input placeholder="Enter primary color" allowClear />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item
                name="secondarycolor"
                label="Secondary Color"
                rules={[
                  {
                    required: true,
                    message: "Please enter the secondary color",
                  },
                ]}
              >
                <Input placeholder="Enter secondary color" allowClear />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item
                name="accentcolor"
                label="Accent Color"
                rules={[
                  { required: true, message: "Please enter the accent color" },
                ]}
              >
                <Input placeholder="Enter accent color" allowClear />
              </Form.Item>
            </Col>
          </Row>

          <div className="flex flex-col sm:flex-row justify-end gap-2 mt-4">
            <Button
              type="primary"
              danger
              onClick={() => setIsModalOpen(false)}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              className="w-full sm:w-auto"
            >
              Submit
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default Colorcombo;
