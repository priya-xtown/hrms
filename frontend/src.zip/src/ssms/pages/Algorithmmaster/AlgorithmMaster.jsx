import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  Switch,
  Tooltip,
  message,
  Popover,
  Dropdown,
  Menu,
} from "antd";
import {
  PlusOutlined,
  EllipsisOutlined,
  FilterOutlined,
  EyeOutlined,
  DeleteOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { useTheme } from "../../../context/ThemeContext";

const { Option } = Select;

// Helper function to get unique values from data
const getUniqueValues = (data, key) =>
  [...new Set(data.map((item) => item[key]))].filter(Boolean);

// FiltersPopover Component
const FiltersPopover = ({ onApply, dataSource, currentFilters }) => {
  const [filters, setFilters] = useState({
    detectionName: currentFilters?.detectionName,
    status: currentFilters?.status,
  });

  const onChange = (field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const renderPopoverContent = (field) => {
    let options = [];

    switch (field) {
      case "detectionName":
        options = getUniqueValues(dataSource, "detection_name");
        break;
      case "status":
        options = ["active", "inactive"];
        break;
      default:
        break;
    }

    return (
      <div>
        <div style={{ marginBottom: 3, fontWeight: "bold", color: "#555" }}>
          {field.split(/(?=[A-Z])/).join(" ")}
        </div>
        <Select
          value={filters[field]}
          onChange={(val) => onChange(field, val)}
          placeholder={`Select ${field
            .split(/(?=[A-Z])/)
            .join(" ")
            .toLowerCase()}`}
          style={{ width: 180 }}
          allowClear
        >
          {options.map((opt) => (
            <Option key={opt} value={opt}>
              {opt}
            </Option>
          ))}
        </Select>
      </div>
    );
  };

  return (
    <div style={{ padding: 10, width: 200, height: "auto" }}>
      {["detectionName", "status"].map((field) => (
        <div key={field} style={{ marginBottom: 15 }}>
          <Popover
            content={renderPopoverContent(field)}
            trigger="hover"
            placement="right"
            mouseEnterDelay={0.1}
            mouseLeaveDelay={0.1}
          >
            <div
              style={{
                cursor: "pointer",
                fontWeight: "semibold",
                width: 100,
                color: filters[field] ? "#1890ff" : "inherit",
              }}
            >
              {field.split(/(?=[A-Z])/).join(" ")}
              {filters[field] && (
                <span className="ml-2 text-xs text-gray-500">(1)</span>
              )}
            </div>
          </Popover>
        </div>
      ))}
      <div style={{ textAlign: "center", marginTop: 20 }} className="space-x-2">
        <Button
          danger
          size="small"
          onClick={() => {
            setFilters({});
            onApply({});
          }}
          disabled={
            Object.keys(filters).filter((k) => filters[k] !== undefined)
              .length === 0
          }
        >
          Reset
        </Button>
        <Button
          type="primary"
          size="small"
          onClick={() => onApply(filters)}
          disabled={
            Object.keys(filters).filter((k) => filters[k] !== undefined)
              .length === 0
          }
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const AlgorithmMasterPage = () => {
  const { primaryColor, contentBgColor } = useTheme();

  const [form] = Form.useForm();
  const [algorithms, setAlgorithms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [searchText, setSearchText] = useState("");

  const handleMenuClick = (record, e) => {
    switch (e.key) {
      case "view":
        // Add your view logic here
        break;
      case "edit":
        handleEdit(record);
        break;
      case "delete":
        handleDelete(record);
        break;
      default:
        break;
    }
  };

  const columns = [
    {
      title: "S.No",
      key: "serialNumber",
      width: 70,
      render: (_, __, index) => index + 1,
      fixed: "left",
    },
    {
      title: "Detection Name",
      dataIndex: "detection_name",
      key: "detection_name",
      sorter: true,
    },
    {
      title: "Description",
      dataIndex: "detection_description",
      key: "detection_description",
    },
    {
      title: "Status",
      dataIndex: "is_active",
      key: "is_active",
      render: (active) => <Switch checked={active} disabled />,
    },
    {
      title: "Created By",
      dataIndex: "created_by",
      key: "created_by",
    },
    {
      title: "Created At",
      dataIndex: "created_at",
      key: "created_at",
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Dropdown
          overlay={
            <Menu onClick={(e) => handleMenuClick(record, e)}>
              <Menu.Item icon={<EyeOutlined />} key="view">
                View
              </Menu.Item>
              <Menu.Item icon={<EditOutlined />} key="edit">
                Edit
              </Menu.Item>
              <Menu.Item icon={<DeleteOutlined />} key="delete">
                Delete
              </Menu.Item>
            </Menu>
          }
          trigger={["click"]}
        >
          <EllipsisOutlined className="cursor-pointer text-lg rotate-90" />
        </Dropdown>
      ),
    },
  ];

  const formLayout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };

  const handleEdit = (record) => {
    setEditingRecord(record);
    form.setFieldsValue(record);
    setModalVisible(true);
  };

  const handleDelete = async (record) => {
    try {
      // Add your delete API call here
      message.success("Algorithm deleted successfully");
      fetchAlgorithms();
    } catch (error) {
      message.error("Failed to delete algorithm");
    }
  };

  const handleSubmit = async (values) => {
    try {
      setLoading(true);
      if (editingRecord) {
        // Add your update API call here
      } else {
        // Add your create API call here
      }
      message.success(
        `Algorithm ${editingRecord ? "updated" : "created"} successfully`
      );
      setModalVisible(false);
      form.resetFields();
      fetchAlgorithms();
    } catch (error) {
      message.error(
        `Failed to ${editingRecord ? "update" : "create"} algorithm`
      );
    } finally {
      setLoading(false);
    }
  };

  const fetchAlgorithms = async () => {
    try {
      setLoading(true);
      // Add your fetch API call here
    } catch (error) {
      message.error("Failed to fetch algorithms");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlgorithms();
  }, []);

  const handleFilterApply = (filters) => {
    const filtered = algorithms.filter((item) => {
      let matches = true;

      if (filters.detectionName) {
        matches = matches && item.detection_name === filters.detectionName;
      }
      if (filters.status) {
        matches = matches && item.is_active === (filters.status === "active");
      }

      return matches;
    });

    setFilteredData(filtered);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: (keys) => setSelectedRowKeys(keys),
    selections: [
      Table.SELECTION_ALL,
      Table.SELECTION_INVERT,
      Table.SELECTION_NONE,
      {
        key: "odd",
        text: "Select Odd Row",
        onSelect: (changableRowKeys) =>
          setSelectedRowKeys(changableRowKeys.filter((_, i) => i % 2 === 0)),
      },
      {
        key: "even",
        text: "Select Even Row",
        onSelect: (changableRowKeys) =>
          setSelectedRowKeys(changableRowKeys.filter((_, i) => i % 2 !== 0)),
      },
    ],
  };

  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchText(val);
    const filtered = algorithms.filter((item) =>
      item.detection_name.toLowerCase().includes(val.toLowerCase())
    );
    setFilteredData(filtered);
  };

  return (
    <div className="min-h-screen flex flex-col overflow-hidden">
      <div className="p-4 bg-white">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0 mb-4">
          <h1 className="text-xl font-semibold">Algorithm Master</h1>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-3 w-full md:w-auto">
            <Input.Search
              placeholder="Search by detection name"
              value={searchText}
              onChange={handleSearchChange}
              className="w-full sm:w-[250px]"
              allowClear
            />
            <div className="flex space-x-2">
              <Popover
                content={
                  <FiltersPopover
                    onApply={handleFilterApply}
                    dataSource={algorithms}
                  />
                }
                trigger="click"
                placement="bottomRight"
              >
                <Button icon={<FilterOutlined />} className="w-full sm:w-auto">
                  Filter
                </Button>
              </Popover>
              {/* <Button
                                type="primary"
                                icon={<PlusOutlined />}
                                onClick={() => {
                                    setEditingRecord(null);
                                    form.resetFields();
                                    setModalVisible(true);
                                }}
                                className="w-full sm:w-auto"
                            >
                                Add Algorithm
                            </Button> */}
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 p-1 overflow-hidden">
        <div className="h-full overflow-auto rounded-lg border border-gray-200">
          <Table
            rowSelection={rowSelection}
            columns={columns}
            dataSource={filteredData.length > 0 ? filteredData : algorithms}
            loading={loading}
            rowKey="id"
            scroll={{ x: "max-content" }}
            pagination={{
              showSizeChanger: true,
              showTotal: (total) => `Total ${total} items`,
              position: ["bottomRight"],
              responsive: true,
            }}
            size="small"
            // components={{
            //     header: {
            //         cell: (props) => (
            //             <th
            //                 {...props}
            //                 style={{
            //                     backgroundColor: primaryColor,
            //                     color: contentBgColor,
            //                     position: 'sticky',
            //                     top: 0,
            //                     zIndex: 2,
            //                     padding: '12px 8px',
            //                     whiteSpace: 'nowrap'
            //                 }}
            //             />
            //         ),
            //     },
            // }}
            className="min-w-full"
          />
        </div>
      </div>

      <Modal
        title={`${editingRecord ? "Edit" : "Add"} Algorithm`}
        open={modalVisible}
        onCancel={() => {
          setModalVisible(false);
          form.resetFields();
        }}
        footer={null}
        destroyOnClose
        className="modern-modal"
        width={800}
        style={{ top: 20 }}
        bodyStyle={{ maxHeight: "calc(100vh - 200px)", overflow: "auto" }}
      >
        <Form
          {...formLayout}
          form={form}
          onFinish={handleSubmit}
          className="p-2 space-y-2"
          layout="vertical"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <Form.Item
              name="detection_name"
              label="Detection Name"
              rules={[
                { required: true, message: "Please enter detection name" },
              ]}
            >
              <Input
                placeholder="Enter detection name"
                className="rounded-lg"
              />
            </Form.Item>

            <Form.Item name="is_active" label="Status" initialValue="active">
              <Select
                placeholder="Select status"
                className="rounded-lg"
                allowClear
                options={[
                  { value: "active", label: "Active" },
                  { value: "inactive", label: "Inactive" },
                ]}
              />
            </Form.Item>

            <Form.Item
              name="detection_description"
              label="Description"
              rules={[{ required: true, message: "Please enter description" }]}
            >
              <Input.TextArea
                placeholder="Enter description"
                className="rounded-lg"
                rows={4}
              />
            </Form.Item>
          </div>

          <Form.Item className="flex justify-end mb-0">
            <Space>
              <Button
                type="primary"
                danger
                onClick={() => setModalVisible(false)}
                className="rounded-lg"
              >
                Cancel
              </Button>
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                className="rounded-lg"
              >
                {editingRecord ? "Update" : "Create"}
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default AlgorithmMasterPage;
