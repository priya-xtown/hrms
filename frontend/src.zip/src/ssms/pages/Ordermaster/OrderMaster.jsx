import React, { useState, useEffect } from "react";

import {
  Table,
  Button,
  Form,
  Input,
  DatePicker,
  Select,
  Switch,
  Upload,
  message,
  Popover,
  Dropdown,
  Menu,
  Modal,
  Space,
} from "antd";

import {
  PlusOutlined,
  EllipsisOutlined,
  FilterOutlined,
  EyeOutlined,
  EditOutlined,
  DeleteOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import { useTheme } from "../../../context/ThemeContext";
import { useNavigate } from "react-router-dom";
import moment from "moment";

const { Option } = Select;

// Helper to get unique values for filters
const getUniqueValues = (data, key) =>
  [...new Set(data.map((item) => item[key]))].filter(Boolean);

// FiltersPopover for OrderMaster fields
const FiltersPopover = ({ onApply, dataSource, currentFilters }) => {
  const [filters, setFilters] = useState({
    order_no: currentFilters?.order_no,
    buyer_name: currentFilters?.buyer_name,
    status: currentFilters?.status,
  });

  const onChange = (field, value) =>
    setFilters((prev) => ({ ...prev, [field]: value }));

  const renderContent = (field) => {
    let options = [];
    switch (field) {
      case "order_no":
        options = getUniqueValues(dataSource, "order_no");
        break;
      case "buyer_name":
        options = getUniqueValues(dataSource, "buyer_name");
        break;
      case "status":
        options = ["active", "inactive"];
        break;
      default:
        break;
    }

    return (
      <div style={{ width: 180 }}>
        <strong style={{ display: "block", marginBottom: 4 }}>
          {field.replace("_", " ")}
        </strong>
        <Select
          placeholder={`Select ${field.replace("_", " ")}`}
          value={filters[field]}
          onChange={(val) => onChange(field, val)}
          allowClear
          style={{ width: "100%" }}
        >
          {options.map((o) => (
            <Option key={o} value={o}>
              {o}
            </Option>
          ))}
        </Select>
      </div>
    );
  };

  const hasAny = Object.values(filters).some((v) => v !== undefined);

  return (
    <div style={{ padding: 10 }}>
      {["order_no", "buyer_name", "status"].map((f) => (
        <div key={f} style={{ marginBottom: 12 }}>
          <Popover content={renderContent(f)} trigger="hover" placement="right">
            <span
              style={{
                cursor: "pointer",
                color: filters[f] ? "#1890ff" : undefined,
              }}
            >
              {f.replace("_", " ")}
              {filters[f] && <sup>●</sup>}
            </span>
          </Popover>
        </div>
      ))}
      <div style={{ textAlign: "right", marginTop: 8 }}>
        <Button
          size="small"
          danger
          onClick={() => {
            setFilters({});
            onApply({});
          }}
          disabled={!hasAny}
          style={{ marginRight: 8 }}
        >
          Reset
        </Button>
        <Button
          size="small"
          type="primary"
          onClick={() => onApply(filters)}
          disabled={!hasAny}
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const OrderMasterPage = () => {
  const { primaryColor, contentBgColor } = useTheme();
  const navigate = useNavigate();
  const [form] = Form.useForm();

  const [orders, setOrders] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({});
  const [searchText, setSearchText] = useState("");

  const [modalVisible, setModalVisible] = useState(false);
  const [editing, setEditing] = useState(null);

  // fetch orders from API
  const fetchOrders = async () => {
    setLoading(true);
    try {
      // TODO: replace with real API call
      // const res = await axios.get('/api/orders');
      // setOrders(res.data);
      setOrders([]); // placeholder
    } catch (e) {
      message.error("Failed to load orders");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  // apply filters + search
  useEffect(() => {
    let data = orders;
    if (filters.order_no) {
      data = data.filter((o) => o.order_no === filters.order_no);
    }
    if (filters.buyer_name) {
      data = data.filter((o) => o.buyer_name === filters.buyer_name);
    }
    if (filters.status) {
      data = data.filter((o) => o.status === filters.status);
    }
    if (searchText) {
      data = data.filter((o) =>
        o.order_no.toLowerCase().includes(searchText.toLowerCase())
      );
    }
    setFiltered(data);
  }, [orders, filters, searchText]);

  const handleFilterApply = (f) => setFilters(f);

  const columns = [
    {
      title: "S.No",
      width: 60,
      render: (_, __, idx) => idx + 1,
      fixed: "left",
    },
    { title: "Order No", dataIndex: "order_no", key: "order_no", sorter: true },
    {
      title: "Order Date",
      dataIndex: "order_date",
      key: "order_date",
      render: (d) => (d ? moment(d).format("YYYY-MM-DD") : "-"),
      sorter: true,
    },
    { title: "Buyer", dataIndex: "buyer_name", key: "buyer_name" },
    {
      title: "Image",
      dataIndex: "image",
      key: "image",
      render: (url) =>
        url ? <img src={url} alt="" style={{ width: 40 }} /> : "-",
    },
    { title: "Style", dataIndex: "style", key: "style" },
    { title: "Color Combo", dataIndex: "color_combo", key: "color_combo" },
    { title: "Part", dataIndex: "part", key: "part" },
    {
      title: "Thread Cons.",
      dataIndex: "thread_consumption",
      key: "thread_consumption",
    },
    {
      title: "Active",
      dataIndex: "is_active",
      key: "is_active",
      render: (v) => <Switch checked={v} disabled />,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (s) => <span>{s}</span>,
      filters: [
        { text: "active", value: "active" },
        { text: "inactive", value: "inactive" },
      ],
      onFilter: (val, rec) => rec.status === val,
    },
    {
      title: "Actions",
      key: "actions",
      fixed: "right",
      render: (_, rec) => (
        <Dropdown
          overlay={
            <Menu onClick={({ key }) => handleMenuClick(key, rec)}>
              <Menu.Item key="view" icon={<EyeOutlined />}>
                View
              </Menu.Item>
              <Menu.Item key="edit" icon={<EditOutlined />}>
                Edit
              </Menu.Item>
              <Menu.Item key="delete" icon={<DeleteOutlined />}>
                Delete
              </Menu.Item>
            </Menu>
          }
          trigger={["click"]}
        >
          <EllipsisOutlined style={{ fontSize: 18 }} rotate={90} />
        </Dropdown>
      ),
    },
  ];

  const handleMenuClick = (action, record) => {
    if (action === "view") {
      // view logic
    } else if (action === "edit") {
      form.setFieldsValue({
        ...record,
        order_date: record.order_date ? moment(record.order_date) : null,
      });
      setEditing(record);
      setModalVisible(true);
    } else if (action === "delete") {
      // delete logic
    }
  };

  const handleSubmit = async (vals) => {
    setLoading(true);
    try {
      const payload = {
        ...vals,
        order_date: vals.order_date.format("YYYY-MM-DD"),
      };
      if (editing) {
        // await axios.put(`/api/orders/${editing.id}`, payload);
        message.success("Order updated");
      } else {
        // await axios.post('/api/orders', payload);
        message.success("Order created");
      }
      setModalVisible(false);
      form.resetFields();
      fetchOrders();
    } catch {
      message.error("Save failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <div className="p-2 bg-white">
        <div className="flex flex-col md:flex-row justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Order Master</h2>
          <div className="flex space-x-2 items-center">
            <Input
              placeholder="Search Order No"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              allowClear
              style={{ width: 200 }}
            />
            <Popover
              content={
                <FiltersPopover
                  onApply={handleFilterApply}
                  dataSource={orders}
                  currentFilters={filters}
                />
              }
              trigger="click"
              placement="bottomRight"
            >
              <Button icon={<FilterOutlined />}>Filter</Button>
            </Popover>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                form.resetFields();
                setEditing(null);
                setModalVisible(true);
              }}
            >
              Add Order
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 p-2 overflow-auto">
        <Table
          rowKey="id"
          columns={columns}
          dataSource={filtered}
          loading={loading}
          scroll={{ x: "max-content" }}
          pagination={{ position: ["bottomRight"] }}
          size="small"

          // components={{
          //     header: {
          //         cell: (props) => (
          //             <th
          //                 {...props}
          //                 style={{
          //                     background: primaryColor,
          //                     color: contentBgColor,
          //                     position: 'sticky',
          //                     top: 0,
          //                     zIndex: 2,
          //                 }}
          //             />
          //         ),
          //     },
          // }}
        />
      </div>

      <Modal
        title={`${editing ? "Edit" : "Add"} Order`}
        open={modalVisible}
        onCancel={() => {
          setModalVisible(false);
          form.resetFields();
        }}
        footer={null}
        destroyOnClose
        className="modern-modal"
        width={800}
        style={{ top: 20 }}
        bodyStyle={{ maxHeight: "calc(100vh - 200px)", overflow: "auto" }}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          initialValues={{ status: "active", is_active: true }}
          className="p-2 space-y-2"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <Form.Item
              name="order_no"
              label="Order No"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="order_date"
              label="Order Date"
              rules={[{ required: true }]}
            >
              <DatePicker style={{ width: "100%" }} />
            </Form.Item>
            <Form.Item
              name="buyer_name"
              label="Buyer Name"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item name="image" label="Image">
              <Upload
                listType="picture"
                beforeUpload={() => false}
                maxCount={1}
              >
                <Button icon={<UploadOutlined />}>Upload</Button>
              </Upload>
            </Form.Item>
            <Form.Item name="style" label="Style">
              <Input type="number" />
            </Form.Item>
            <Form.Item name="color_combo" label="Color Combo">
              <Input type="number" />
            </Form.Item>
            <Form.Item name="part" label="Part">
              <Input type="number" />
            </Form.Item>
            <Form.Item name="thread_consumption" label="Thread Consumption">
              <Input type="number" step="0.01" />
            </Form.Item>
            <Form.Item name="is_active" label="Active" valuePropName="checked">
              <Switch />
            </Form.Item>
            <Form.Item name="status" label="Status">
              <Select>
                <Option value="active">active</Option>
                <Option value="inactive">inactive</Option>
              </Select>
            </Form.Item>
          </div>
          <Form.Item className="flex justify-end mb-0">
            <Space>
              <Button
                type="primary"
                danger
                onClick={() => setModalVisible(false)}
                className="rounded-lg"
              >
                Cancel
              </Button>
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                className="rounded-lg"
              >
                {editing ? "Update" : "Create"}
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default OrderMasterPage;
