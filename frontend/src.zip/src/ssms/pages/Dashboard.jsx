const SsmsDashboard = () => (
  <div className="text-2xl font-semibold">SSMS Dashboard Content</div>
);

export default SsmsDashboard;
