import { useState, useEffect } from "react";
import {
  Table,
  Button,
  Input,
  Select,
  Popover,
  message,
  Dropdown,
  Menu,
  Tag,
  Space,
  Switch,
  Card,
} from "antd";
import {
  PlusOutlined,
  EllipsisOutlined,
  FilterOutlined,
  DeleteOutlined,
  EditOutlined,
  SettingOutlined,
  AppstoreOutlined,
  TableOutlined,
} from "@ant-design/icons";
import { useTheme } from "../../../context/ThemeContext";
import { useNavigate } from "react-router-dom";
import { companyService } from "../../../company/services/CompanyServices";
import { divisionService } from "../../../company/services/divisionService";
import { departmentService } from "../../../company/services/departmentService";
import { branchServices } from "../../../company/services/CompanyServices";
import { controllerService } from "../../services/Controller";
import { machineService } from "../../services/Machineservices";

const { Option } = Select;

const FiltersPopover = ({
  onApply,
  companies,
  divisions,
  branches,
  departments,
  lines,
}) => {
  const [filters, setFilters] = useState({
    companyId: undefined,
    divisionId: undefined,
    branchId: undefined,
    departmentId: undefined,
    lineId: undefined,
    status: undefined,
  });

  const onChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  const fields = [
    {
      key: "divisionId",
      label: "Division",
      options: divisions.map((d) => ({ label: d.name, value: d.id })),
    },
    {
      key: "branchId",
      label: "Branch",
      options: branches.map((b) => ({ label: b.name, value: b.id })),
    },
    {
      key: "departmentId",
      label: "Department",
      options: departments.map((d) => ({ label: d.name, value: d.id })),
    },

    {
      key: "status",
      label: "Status",
      options: [
        { label: "Active", value: "active" },
        { label: "Inactive", value: "inactive" },
      ],
    },
  ];

  return (
    <div style={{ padding: 10, width: 240 }}>
      {fields.map(({ key, label, options }) => (
        <div key={key} style={{ marginBottom: 15 }}>
          <Popover
            content={
              <div>
                <div
                  style={{ marginBottom: 6, fontWeight: 600, color: "#555" }}
                >
                  {label}
                </div>
                <Select
                  showSearch
                  allowClear
                  placeholder={`Select ${label.toLowerCase()}`}
                  style={{ width: 200 }}
                  value={filters[key]}
                  onChange={(val) => onChange(key, val)}
                  mode="multiple"
                >
                  {options.map((opt) => (
                    <Option key={opt.value} value={opt.value}>
                      {opt.label}
                    </Option>
                  ))}
                </Select>
              </div>
            }
            trigger="hover"
            placement="right"
            mouseEnterDelay={0.1}
            mouseLeaveDelay={0.1}
          >
            <div
              style={{
                cursor: "pointer",
                fontWeight: 500,
                color: filters[key] ? "#1890ff" : "inherit",
              }}
            >
              {label}
              {filters[key] && (
                <span style={{ marginLeft: 4 }}>({filters[key].length})</span>
              )}
            </div>
          </Popover>
        </div>
      ))}

      <div style={{ textAlign: "center", marginTop: 10 }}>
        <Button
          danger
          size="small"
          onClick={() => {
            setFilters({
              companyId: undefined,
              divisionId: undefined,
              branchId: undefined,
              departmentId: undefined,
              lineId: undefined,
              status: undefined,
            });
            onApply({});
          }}
          disabled={!Object.values(filters).some((v) => v !== undefined)}
        >
          Reset
        </Button>
        <Button
          type="primary"
          size="small"
          style={{ marginLeft: 8 }}
          onClick={() =>
            onApply({
              company_id: filters.companyId,
              division_id: filters.divisionId,
              branch_id: filters.branchId,
              department_id: filters.departmentId,
              line_id: filters.lineId,
              status: filters.status,
            })
          }
          disabled={!Object.values(filters).some((v) => v !== undefined)}
        >
          Apply
        </Button>
      </div>
    </div>
  );
};

const MachinePage = () => {
  const { primaryColor, contentBgColor, showCustomButton } = useTheme();
  const [machines, setMachines] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [companies, setCompanies] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [branches, setBranches] = useState([]);
  const [lines, setLines] = useState([]);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const navigate = useNavigate();

  const [viewMode, setViewMode] = useState(
    localStorage.getItem("machineViewMode") || "table"
  );
  useEffect(() => {
    localStorage.setItem("machineViewMode", viewMode);
  }, [viewMode]);

  useEffect(() => {
    const fetchMasters = async () => {
      try {
        const [companyRes, divisionRes, departmentRes, branchRes, lineRes] =
          await Promise.all([
            companyService.getCompany(),
            divisionService.getAllDivisions(),
            departmentService.getAllDepartments(),
            branchServices.getBranch(),
            controllerService.getAllController(),
          ]);

        setCompanies(
          Array.isArray(companyRes?.data?.data) ? companyRes.data.data : []
        );
        setDivisions(
          Array.isArray(divisionRes?.data?.divisions)
            ? divisionRes.data.divisions
            : []
        );
        setDepartments(
          Array.isArray(departmentRes?.data?.departments)
            ? departmentRes.data.departments
            : []
        );
        setBranches(
          Array.isArray(branchRes?.data?.data?.branches)
            ? branchRes.data.data.branches
            : []
        );
        setLines(Array.isArray(lineRes?.data) ? lineRes.data : []);
      } catch (error) {
        console.error("Error fetching master data:", error);
        message.error("Failed to load filter lists");
      }
    };

    fetchMasters();
  }, []);

  const fetchMachines = async (params = {}) => {
    setLoading(true);
    try {
      const response = await machineService.getMachines({
        page: params.page || pagination.current,
        limit: params.pageSize || pagination.pageSize,
        search: searchText,
        sort_by: "created_at",
        sort_order: "desc",
        status: params.status,
        // company_id: params.company_id,
        // division_id: params.division_id,
        // branch_id: params.branch_id,
        // department_id: params.department_id,
        // line_id: params.line_id,
      });

      if (!response.success) {
        throw new Error(response.error || "Unknown error fetching machines");
      }

      const { data: rows, meta } = response.data;
      setMachines(rows);
      setPagination({
        current: meta.page,
        pageSize: meta.limit,
        total: meta.total,
      });
    } catch (err) {
      console.error("Error fetching machines:", err);
      message.error(err.message || "Failed to fetch machines");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMachines();
  }, [searchText, pagination.current, pagination.pageSize]);

  const handleFilterApply = (params) => {
    setPagination((prev) => ({ ...prev, current: 1 }));
    fetchMachines({ ...params, page: 1, pageSize: pagination.pageSize });
  };

  const handleSearchChange = (e) => {
    setSearchText(e.target.value);
    setPagination((prev) => ({ ...prev, current: 1 }));
  };

  const handleMenuClick = (record, e) => {
    if (e.key === "edit") {
      navigate(`/ssms/pages/machinemaster/create`, {
        state: { isEdit: true, initialValues: record },
      });
    }
    if (e.key === "delete") {
      machineService.deleteMachine(record.id).then(() => fetchMachines());
    }
  };

  const capitalizeWords = (text) => {
    if (!text || typeof text !== "string") return "-";
    return text
      .toLowerCase()
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const handleDelete = async (record) => {
    try {
      await controllerService.deleteController(record.id);
      messageApi.success("Controller deleted successfully");
      fetchController();
    } catch (error) {
      messageApi.error("Failed to delete controller");
    }
  };

  const [visibleColumns, setVisibleColumns] = useState(() => {
    const saved = localStorage.getItem("machineVisibleColumns");
    return saved
      ? JSON.parse(saved)
      : [
          "machine_name",
          "company_name",
          "branch_name",
          "department_name",
          "division_name",
          "machine_type",
          "location",
          "purchase_date",
          "status",
          "actions",
        ];
  });
  useEffect(() => {
    localStorage.setItem(
      "machineVisibleColumns",
      JSON.stringify(visibleColumns)
    ),
      [visibleColumns];
  });

  const allColumns = [
    {
      title: "S.No",
      key: "idx",
      width: 60,
      fixed: "left",
      render: (_, __, index) =>
        (pagination.current - 1) * pagination.pageSize + index + 1,
    },
    {
      title: "Company",
      dataIndex: ["company", "name"],
      key: "company_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Division",
      dataIndex: ["division", "name"],
      key: "division_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Branch",
      dataIndex: ["branch", "name"],
      key: "branch_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Department",
      dataIndex: ["department", "name"],
      key: "department_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Machine Name",
      dataIndex: "machine_name",
      key: "machine_name",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Machine Type",
      dataIndex: ["machine_types", "machine_type"],
      key: "machine_type",
      sorter: true,
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Location",
      dataIndex: "location",
      key: "location",
      render: (name) => capitalizeWords(name),
    },
    {
      title: "Serial No",
      dataIndex: "serial_number",
      key: "serial_number",
    },
    {
      title: "Purchase Date",
      dataIndex: "purchase_date",
      key: "purchase_date",
      render: (date) => (date ? new Date(date).toLocaleDateString() : "-"),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => {
        if (!status) return "-";
        const normalizedStatus = status.toLowerCase();
        const label =
          status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
        return (
          <Tag color={normalizedStatus === "active" ? "green" : "red"}>
            {label}
          </Tag>
        );
      },
    },
    ,
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Dropdown
          overlay={
            <Menu onClick={(e) => handleMenuClick(record, e)}>
              <Menu.Item icon={<EditOutlined />} key="edit">
                Edit
              </Menu.Item>
              <Menu.Item icon={<DeleteOutlined />} key="delete">
                Delete
              </Menu.Item>
            </Menu>
          }
          trigger={["click"]}
        >
          <EllipsisOutlined className="cursor-pointer text-lg rotate-90" />
        </Dropdown>
      ),
    },
  ];
  const columns = allColumns.filter((c) => visibleColumns.includes(c.key));
  return (
    <div className="max-w-full overflow-hidden">
      <div className=" bg-white flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-2">
        <h1 className="text-xl font-semibold">Machine</h1>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
          <div className="w-full sm:w-[250px] min-w-[200px]">
            <Input.Search
              placeholder="Search machines"
              value={searchText}
              onChange={handleSearchChange}
              className="w-full sm:w-[250px]"
              allowClear
            />
          </div>
          <Popover
            content={
              <FiltersPopover
                onApply={handleFilterApply}
                companies={companies}
                divisions={divisions}
                branches={branches}
                departments={departments}
                lines={lines}
              />
            }
            trigger="click"
            placement="bottomRight"
          >
            <Button icon={<FilterOutlined />}>Filter</Button>
          </Popover>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => navigate("/ssms/pages/machinemaster/create")}
          >
            Add Machine
          </Button>
          {showCustomButton && (
            <Dropdown
              menu={{
                items: allColumns.map((col) => ({
                  key: col.key,
                  label: (
                    <Space>
                      <Switch
                        checked={visibleColumns.includes(col.key)}
                        onChange={(chk) => {
                          setVisibleColumns((vs) =>
                            chk
                              ? [...vs, col.key]
                              : vs.filter((k) => k !== col.key)
                          );
                        }}
                      />
                      {col.title}
                    </Space>
                  ),
                })),
              }}
            >
              <Button icon={<SettingOutlined />} />
            </Dropdown>
          )}
          <Button
            icon={
              viewMode === "table" ? <AppstoreOutlined /> : <TableOutlined />
            }
            onClick={() =>
              setViewMode((m) => (m === "table" ? "card" : "table"))
            }
          >
            {/* {viewMode === "table" ? "Card View" : "Table View"} */}
          </Button>
        </div>
      </div>
      {viewMode === "table" ? (
        <div className="overflow-x-auto">
          <Table
            columns={columns}
            dataSource={machines}
            loading={loading}
            rowKey="id"
            scroll={{ x: "max-content" }}
            pagination={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              showSizeChanger: true,
              showTotal: (total, range) =>
                `${range[0]}–${range[1]} of ${total} items`,
              onChange: (page, pageSize) => {
                setPagination((prev) => ({ ...prev, current: page, pageSize }));
                fetchMachines({ page, pageSize });
              },
            }}
            locale={{
              emptyText: loading ? "Loading..." : "No data found",
            }}
            size="small"
            components={{
              header: {
                cell: (props) => (
                  <th
                    {...props}
                    style={{
                      position: "sticky",
                      top: 0,
                      zIndex: 2,
                      padding: "8px 8px",
                      whiteSpace: "nowrap",
                    }}
                  />
                ),
              },
            }}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {machines.length ? (
            machines.map((rec, i) => (
              <Card
                key={rec.id}
                title={`${
                  (pagination.current - 1) * pagination.pageSize + i + 1
                }. ${rec.machine_name}`}
                className="shadow-sm hover:shadow-md"
              >
                <p>
                  <strong>Company:</strong> {rec.company?.name}
                </p>
                <p>
                  <strong>Division:</strong> {rec.division?.name}
                </p>
                <p>
                  <strong>Branch:</strong> {rec.branch?.name}
                </p>
                <p>
                  <strong>Department:</strong> {rec.department?.name}
                </p>
                <p>
                  <strong>Type:</strong> {rec.machine_types?.machine_type}
                </p>
                <p>
                  <strong>Location:</strong> {rec.location}
                </p>
                <p>
                  <strong>Purchased:</strong> {rec.purchase_date}
                </p>
                <p>
                  <strong>Status:</strong>{" "}
                  <Tag color={rec.status === "active" ? "green" : "red"}>
                    {rec.status}
                  </Tag>
                </p>
                <Dropdown
                  overlay={
                    <Menu onClick={(e) => handleMenuClick(rec, e)}>
                      <Menu.Item icon={<EditOutlined />} key="edit">
                        Edit
                      </Menu.Item>
                      <Menu.Item icon={<DeleteOutlined />} key="delete">
                        Delete
                      </Menu.Item>
                    </Menu>
                  }
                  trigger={["click"]}
                >
                  <EllipsisOutlined
                    rotate={90}
                    className="cursor-pointer text-lg"
                  />
                </Dropdown>
              </Card>
            ))
          ) : (
            <div className="py-10 text-center">No machines found</div>
          )}
        </div>
      )}
    </div>
  );
};

export default MachinePage;
