import { useState, useEffect } from "react";
import { Form, Input, Select, DatePicker, Button, Space, message } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import { companyService } from "../../../company/services/CompanyServices";
import { divisionService } from "../../../company/services/divisionService";
import { departmentService } from "../../../company/services/departmentService";
import { branchServices } from "../../../company/services/CompanyServices";
import { machineService } from "../../services/Machineservices";
import { controllerService } from "../../services/Controller";
import { machineTypeService } from "../../services/machinetype";

import moment from "moment";

const CreateMachine = () => {
  const { state } = useLocation();
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const [companies, setCompanies] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [branches, setBranches] = useState([]);
  const [lines, setLines] = useState([]);
  const [machineTypes, setMachineTypes] = useState([]);
  const [loading, setLoading] = useState(false);

  const isEdit = !!state?.isEdit;
  const pageTitle = isEdit ? "Edit Machine" : "Add New Machine";

  // If we're in edit mode and have initialValues (including `status`), populate the form.
  useEffect(() => {
    if (isEdit && state.initialValues) {
      form.setFieldsValue({
        ...state.initialValues,
        purchase_date: state.initialValues.purchase_date
          ? moment(state.initialValues.purchase_date)
          : null,
        // Ensure that if `state.initialValues.status` exists, it will fill the Status Select
        status: state.initialValues.status || "active",
      });
    }
  }, [form, isEdit, state]);

  // Fetch dropdown data on mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [
          companyRes,
          divisionRes,
          departmentRes,
          branchRes,
          lineRes,
          typeRes,
        ] = await Promise.all([
          companyService.getCompany(),
          divisionService.getAllDivisions(),
          departmentService.getAllDepartments(),
          branchServices.getBranch(),
          controllerService.getAllController(),
          machineTypeService.getAllMachineTypes(),
        ]);

        setCompanies(
          Array.isArray(companyRes?.data?.data) ? companyRes.data.data : []
        );
        setDivisions(
          Array.isArray(divisionRes?.data?.divisions)
            ? divisionRes.data.divisions
            : []
        );
        setDepartments(
          Array.isArray(departmentRes?.data?.departments)
            ? departmentRes.data.departments
            : []
        );
        setBranches(
          Array.isArray(branchRes?.data?.data?.branches)
            ? branchRes.data.data.branches
            : []
        );
        setLines(Array.isArray(lineRes?.data?.data) ? lineRes.data.data : []);

        if (Array.isArray(typeRes?.data?.data)) {
          const options = typeRes.data.data.map((t) => ({
            value: t.id,
            label: t.machine_type,
          }));
          setMachineTypes(options);
        } else {
          setMachineTypes([]);
        }
      } catch (error) {
        message.error("Failed to fetch dropdown data");
      }
    };

    fetchData();
  }, []);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      // Build the payload.  For “create” always send status: "active".
      const basePayload = {
        machine_name: values.machine_name,
        machine_type: values.machine_type,
        machine_number: values.machine_number,
        location: values.location,
        serial_number: Number(values.serial_number),
        purchase_date: values.purchase_date
          ? values.purchase_date.format("YYYY-MM-DD") + "T00:00:00.000Z"
          : new Date().toISOString(),
      };

      let payload;
      if (isEdit) {
        // In edit mode, take whatever status the user selected (active/inactive).
        payload = {
          ...basePayload,
          status: values.status,
        };
      } else {
        // In create mode, we never showed a status field, so force it to "active".
        payload = {
          ...basePayload,
          status: "active",
        };
      }

      console.log("Submitting payload:", payload);

      if (isEdit) {
        await machineService.updateMachine(state.initialValues.id, payload);
        message.success("Machine updated successfully");
      } else {
        await machineService.createMachine(payload);
        message.success("Machine created successfully");
      }

      form.resetFields();
      navigate("/ssms/pages/machinemaster");
    } catch (error) {
      console.error("Submission error:", error);
      const errorMessage = error.response?.data?.message || error.message;
      message.error(
        `Failed to ${isEdit ? "update" : "create"} machine: ${errorMessage}`
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-2 bg-white">
      <div className="max-w-8xl mx-auto">
        <h1 className="text-xl font-semibold mb-3">{pageTitle}</h1>

        <Form
          form={form}
          onFinish={handleSubmit}
          layout="vertical"
          className="space-y-4"
        >
          <div className="grid xs:grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <Form.Item
              name="machine_name"
              label="Machine Brand"
              rules={[{ required: true, message: "Please enter machine name" }]}
            >
              <Input placeholder="Enter machine name" className="rounded-lg" />
            </Form.Item>

            <Form.Item
              name="machine_number"
              label="Machine Number"
              rules={[
                { required: true, message: "Please enter machine number" },
              ]}
            >
              <Input
                placeholder="Enter machine number"
                className="rounded-lg"
              />
            </Form.Item>

            <Form.Item
              name="machine_type"
              label="Machine Type"
              rules={[
                { required: true, message: "Please select machine type" },
              ]}
            >
              <Select
                showSearch
                placeholder="Select machine type"
                className="rounded-lg"
                optionFilterProp="label"
                allowClear
                filterOption={(input, option) =>
                  option.label.toLowerCase().includes(input.toLowerCase())
                }
                options={machineTypes}
              />
            </Form.Item>

            <Form.Item
              name="location"
              label="Location"
              rules={[{ required: true, message: "Please enter location" }]}
            >
              <Input placeholder="Enter location" className="rounded-lg" />
            </Form.Item>

            <Form.Item
              name="serial_number"
              label="Serial Number"
              rules={[
                { required: true, message: "Please enter serial number" },
                {
                  pattern: /^[1-9]\d*$/,
                  message: "Serial number must be a positive integer",
                },
              ]}
            >
              <Input
                placeholder="Enter serial number"
                className="rounded-lg"
                type="number"
              />
            </Form.Item>

            <Form.Item
              name="purchase_date"
              label="Purchase Date"
              initialValue={moment()}
              rules={[
                { required: true, message: "Please select purchase date" },
              ]}
            >
              <DatePicker className="w-full rounded-lg" format="YYYY-MM-DD" />
            </Form.Item>

            {/* Only show Status field when editing */}
            {isEdit && (
              <Form.Item
                name="status"
                label="Status"
                rules={[{ required: true, message: "Please select status" }]}
              >
                <Select
                  placeholder="Select status"
                  className="rounded-lg"
                  options={[
                    { value: "active", label: "Active" },
                    { value: "inactive", label: "Inactive" },
                  ]}
                />
              </Form.Item>
            )}
          </div>

          <Form.Item className="flex justify-end mt-6">
            <Space>
              <Button
                danger
                onClick={() => navigate("/ssms/pages/machinemaster")}
                className="rounded-lg"
              >
                Cancel
              </Button>
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                className="rounded-lg"
              >
                {isEdit ? "Update Machine" : "Create Machine"}
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default CreateMachine;
