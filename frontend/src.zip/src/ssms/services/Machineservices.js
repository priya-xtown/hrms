import api from "./api.js";
import { message } from "antd";

function extractMessage(response, defaultMsg) {
  const msg = response.data?.message || defaultMsg;
  console.log("Extracted success message:", msg);
  return msg;
}
// Helper function to validate ISO date string
function isValidISOString(dateString) {
  try {
    const date = new Date(dateString);
    return (
      date instanceof Date && !isNaN(date) && date.toISOString() === dateString
    );
  } catch {
    return false;
  }
}

function extractErrorMessage(error, defaultMsg) {
  let errMsg;
  if (error.response) {
    errMsg =
      error.response.data?.message ||
      error.response.data?.error ||
      (Array.isArray(error.response.data?.errors)
        ? error.response.data.errors.join(", ")
        : error.response.data?.errors) ||
      defaultMsg ||
      "Something went wrong";
  } else if (error.request) {
    errMsg = "Network error: Unable to reach the server";
  } else {
    errMsg = error.message || "Unexpected error occurred";
  }
  console.error("Extracted error message:", errMsg, "Error details:", error);
  return errMsg;
}

export const machineService = {
  createMachine: async (machineData) => {
    try {
      const res = await api.post("ssms/machine/", machineData);
      const msg = extractMessage(res, "Machine created successfully");
      message.success(msg);
      return { success: true, data: res.data, statusCode: res.status };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to create machine");
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid machine data provided");
          break;
        case 404:
          errMsg = "Resource not found";
          break;
        case 409:
          errMsg = "Duplicate data entered. Please check your input";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = "Network error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },

  getMachines: async (params = {}) => {
    const qp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") qp.append(k, v);
    });

    const url = qp.toString()
      ? `ssms/machine/?${qp.toString()}`
      : "ssms/machine/";

    try {
      const res = await api.get(url);
      return { success: true, data: res.data, statusCode: res.status };
    } catch (error) {
      const status = error.response?.status;
      const errMsg = extractErrorMessage(error, "Failed to fetch machines");
      return { success: false, error: errMsg, statusCode: status };
    }
  },

  getMachineById: async (id) => {
    try {
      const res = await api.get(`ssms/machine/${id}/`);
      message.success("Fetched machine details");
      return { success: true, data: res.data, statusCode: res.status };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(
        error,
        "Failed to fetch machine details"
      );
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid request");
          break;
        case 404:
          errMsg = "Machine not found";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = "Network error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },

  updateMachine: async (id, data) => {
    try {
      const payload = {
        machine_name: data.machine_name,
        machine_type: data.machine_type,
        machine_number: data.machine_number,
        location: data.location,
        serial_number: Number(data.serial_number),
        purchase_date: data.purchase_date
          ? data.purchase_date 
          : new Date().toISOString(),
        status: (data.status || "active" || "inactive"),
      };

      const requiredFields = [
        "machine_name",
        "machine_type",
        "machine_number",
        "location",
        "serial_number",
        "status",
        // "company_id", /
        // "division_id",
        // "branch_id",
        // "department_id",
        // "line_id",
      ];
      const missing = requiredFields.filter((f) => !payload[f]);
      if (missing.length) {
        throw new Error(`Missing required fields: ${missing.join(", ")}`);
      }

      // Validate ISO date format
      if (
        payload.purchase_date &&
        !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z$/.test(
          payload.purchase_date
        )
      ) {
        throw new Error(
          "Invalid purchase_date format (must be full ISO string)"
        );
      }

      const res = await api.put(`ssms/machine/${id}/`, payload);
      const msg = extractMessage(res, "Machine updated successfully");
      message.success(msg);
      return { success: true, data: res.data, statusCode: res.status };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to update machine");
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid machine data provided");
          break;
        case 404:
          errMsg = "Machine not found";
          break;
        case 409:
          errMsg = "Duplicate data entered. Please check your input";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = "Network error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },

  partialUpdateMachine: async (id, partialData) => {
    try {
      const res = await api.patch(`ssms/machine/${id}/`, partialData);
      const msg = extractMessage(res, "Machine partially updated");
      message.success(msg);
      return { success: true, data: res.data, statusCode: res.status };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(
        error,
        "Failed to partially update machine"
      );
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid machine data provided");
          break;
        case 404:
          errMsg = "Machine not found";
          break;
        case 409:
          errMsg = "Duplicate data entered. Please check your input";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = "Network error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },

  deleteMachine: async (id) => {
    try {
      const res = await api.delete(`ssms/machine/${id}/`);
      const msg = extractMessage(res, "Machine deleted successfully");
      message.success(msg);
      return { success: true, data: res.data, statusCode: res.status };
    } catch (error) {
      const status = error.response?.status;
      let errMsg = extractErrorMessage(error, "Failed to delete machine");
      switch (status) {
        case 400:
          errMsg = extractErrorMessage(error, "Invalid request");
          break;
        case 404:
          errMsg = "Machine not found";
          break;
        case 429:
          errMsg = "Too many requests. Please wait a few minutes";
          break;
        case 500:
          errMsg = "Network error. Please try again later";
          break;
      }
      message.error(errMsg);
      return { success: false, error: errMsg, statusCode: status };
    }
  },
  getAllController: async () => {
    const response = await api.get("/ssms/line");
    return response.data;
  },
};

export const lineservice = {
  getAllController: async () => {
    const response = await api.get("/ssms/line");
    return response.data;
  },
};
