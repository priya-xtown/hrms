import api from './api';
import { message } from 'antd';

export const machineTypeService = {
  // Get all machine types
  async getAllMachineTypes() {
    try {
      const response = await api.get('/ssms/machinetype');
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      message.error('Failed to fetch machine types');
      return {
        success: false,
        error: error.response?.data?.message || 'Error fetching machine types'
      };
    }
  },

  // Create new machine type
  async createMachineType(data) {
    try {
      const response = await api.post('/ssms/machinetype', data);
      message.success('Machine type created successfully');
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      message.error('Failed to create machine type');
      return {
        success: false,
        error: error.response?.data?.message || 'Error creating machine type'
      };
    }
  },

  async getMachineTypeById(id) {
  try {
    const response = await api.get(`/ssms/machinetype/${id}`);
    return {
      success: true,
      data: response.data
    };
  } catch (error) {
    message.error('Failed to fetch machine type details');
    return {
      success: false,
      error: error.response?.data?.message || 'Error fetching machine type details'
    };
  }
},
  // Update machine type
  async updateMachineType(id, data) {
    try {
      const response = await api.put(`/ssms/machinetype/${id}`, data);
      message.success('Machine type updated successfully');
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      message.error('Failed to update machine type');
      return {
        success: false,
        error: error.response?.data?.message || 'Error updating machine type'
      };
    }
  },

  // Delete machine type
  async deleteMachineType(id) {
    try {
      const response = await api.delete(`/ssms/machinetype/${id}`);
      message.success('Machine type deleted successfully');
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      message.error('Failed to delete machine type');
      return {
        success: false,
        error: error.response?.data?.message || 'Error deleting machine type'
      };
    }
  }
};